"""页面示例插件：最小可用的「插件页面 + 事件钩子」样板。

两个能力各演示一件事：
1. `contributes.pages` —— page.html 会在工作台里以 iframe 打开（路由 plugin:<id>:<page id>），
   页面通过带 token 的 /api 调用拿数据，相对路径的 style.css / 脚本都能正常加载。
2. `contributes.hooks` —— 保存文件后工作台会调 `on_file_saved(payload)`，
   调用发生在**后台线程**里且有超时，所以这里直接做轻量记账就行，不要写耗时逻辑。

注意：钩子事件只在 manifest.hooks 里声明过才会被投递（声明式，避免"偷偷加钩子"）。
"""
from __future__ import annotations

MAX_EVENTS = 20

# 内存里留最近几条事件（演示用；重启就清空，不落盘）
_EVENTS: list[dict] = []


def on_file_saved(payload: dict) -> None:
    """file.saved 钩子：文件保存成功后由工作台调用（后台线程，2s 超时）。"""
    _EVENTS.insert(0, {
        "path": str(payload.get("path", "")),
        "name": str(payload.get("name", "")),
        "size": int(payload.get("size") or 0),
        "encoding": str(payload.get("encoding", "")),
    })
    del _EVENTS[MAX_EVENTS:]


def register(api) -> None:
    @api.command("pagedemo.stats", "页面示例：事件统计", group="插件",
                 description="返回本插件收到的事件（页面示例用来展示「钩子真的被调用了」）",
                 silent=True, keywords="demo 页面 钩子 事件")
    def stats() -> dict:
        # 自配置：读 manifest.contributes.settings 里声明的项（未保存时用 default）
        greeting = api.get_setting("greeting", "你好，运维同学")
        show_count = api.get_setting("showCount", True)
        return {"data": {"count": len(_EVENTS), "events": list(_EVENTS),
                         "hooked": ["file.saved"], "greeting": greeting,
                         "show_count": show_count}}
