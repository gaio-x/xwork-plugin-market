"""页面示例插件（manifest v2 扩展点样板）。

演示七件事：
1. `contributes.pages`    —— 插件自己的页面（iframe 打开，路由 plugin:<id>:<page id>）
2. `contributes.panels`   —— 往**内置页**（这里是首页）底部嵌一块面板
3. `contributes.menus`    —— 往文件页工具栏加一个按钮
4. `contributes.hooks`    —— 订阅 file.saved 事件，保存文件后做轻量记账
5. `api.route(...)`       —— 插件自有 HTTP 接口 `/api/plugins/<id>/x/stats`
6. `api.every(...)`       —— 每 60s 的周期任务，插件停用自动停
7. `api.on_activate/on_deactivate` —— 生命周期回调，累计激活次数

页面与面板都从 `/x/stats` 取数：问候语、是否显示保存计数、自动刷新间隔三项自配置
在这里随快照一起下发，所以页面不需要另调设置接口，也不会出现「设置改了页面没反应」。

钩子（contributes.hooks）仍是 file.saved：保存文件后工作台会调 on_file_saved(payload)，
调用发生在后台线程池里，所以这里只做轻量记账，不要写耗时逻辑。
"""
from __future__ import annotations

import time

MAX_EVENTS = 20

# 内存里留最近几条事件（演示用；重启就清空，不落盘）
_EVENTS: list[dict] = []
_STATE = {"activations": 0, "heartbeats": 0, "last_beat": 0}


def on_file_saved(payload: dict) -> None:
    """file.saved 钩子：文件保存成功后由工作台调用（后台线程，不阻塞保存）。"""
    _EVENTS.insert(0, {
        "path": str(payload.get("path", "")),
        "name": str(payload.get("name", "")),
        "size": int(payload.get("size") or 0),
        "encoding": str(payload.get("encoding", "")),
    })
    del _EVENTS[MAX_EVENTS:]


def _snapshot(api) -> dict:
    """页面 / 面板 / pagedemo.stats 命令共用的快照。

    三个自配置项随快照一起下发：改了设置，页面下次刷新（或自动刷新）就能看到，
    不必让插件页自己去读设置接口，也不用把默认值在前后端各写一份。
    """
    return {
        "count": len(_EVENTS),
        "events": list(_EVENTS),
        "hooked": ["file.saved"],
        "greeting": api.get_setting("greeting", "你好，运维同学"),
        "show_count": api.get_setting("showCount", True),
        "refresh_ms": api.get_setting("refreshMs", 3000),
        "contributes": ["pages", "panels", "menus", "hooks", "settings",
                        "api.route", "api.every", "lifecycle"],
        "state": dict(_STATE),
    }


def register(api) -> None:
    @api.on_activate
    def _on_activate() -> None:
        _STATE["activations"] += 1
        api.log("页面示例插件已激活")

    @api.on_deactivate
    def _on_deactivate() -> None:
        api.log("页面示例插件已停用，定时任务已随之停止")

    @api.every(60, name="heartbeat")
    def _heartbeat() -> None:
        """每 60s 一次的心跳：证明"插件可以带后台任务，且停用后不再跑"。"""
        _STATE["heartbeats"] += 1
        _STATE["last_beat"] = int(time.time())

    @api.route("stats")
    def _route_stats(ctx: dict) -> dict:
        """GET /api/plugins/xwork.page-demo/x/stats —— 插件自有接口。"""
        return _snapshot(api)

    @api.command("pagedemo.stats", "页面示例：事件统计", group="插件",
                 description="返回本插件收到的事件（页面示例用来展示「钩子真的被调用了」）",
                 silent=True, keywords="demo 页面 钩子 事件")
    def stats() -> dict:
        return {"data": _snapshot(api)}

    @api.command("pagedemo.refresh", "页面示例：刷新计数", group="插件", silent=True,
                 description="清空本插件记录的事件计数（工具栏按钮用它演示 menus 扩展点）",
                 keywords="demo 刷新 计数")
    def refresh() -> dict:
        n = len(_EVENTS)
        _EVENTS.clear()
        return {"data": {"cleared": n}}
