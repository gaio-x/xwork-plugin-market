# 页面示例（xwork.page-demo）

> 版本 v1.0.0 ｜ 清单 v2 ｜ 命名空间 `pagedemo` ｜ 主程序要求 `>=0.1.0` ｜ 权限 `ui.inject`

## 这个插件做什么

一个可以直接照着改的样板：把 manifest v2 里"插件能往主界面伸手"的几种方式各演示一遍——
自己的独立页面、往首页底部嵌一块面板、往文件页工具栏加一个按钮、插件自有 HTTP 接口、
每 60 秒跑一次的定时任务、文件保存后触发的事件钩子，以及生命周期回调。实际用途是验收：
「文件保存后到底有没有通知到插件」这类问题，打开它的页面看一眼计数就知道了；
想写自己的工具页，把 `page.html` + `style.css` + 这段 `backend.py` 抄走改最快。

## 怎么用

**命令面板**：`pagedemo.stats` 返回当前事件快照，`pagedemo.refresh` 把事件计数清零，
两条都不需要参数。

**插件页**：启用后按钮「打开「页面示例」」进入插件自己的页面（iframe 内渲染）。
页面顶部显示问候语，下面四张卡片分别是保存次数、激活次数、心跳次数与声明的钩子，
再列出最近 20 条保存事件和本插件用到的扩展点清单；按设置的间隔自动刷新。

**内置页里的入口**（需 `ui.inject`）：首页底部出现「最近保存（页面示例插件）」面板；
文件页工具栏多一个「刷新插件计数」按钮，点了执行 `pagedemo.refresh`。

## 提供的能力

| 命令 id | 名称 | 参数 | 说明 |
|---|---|---|---|
| `pagedemo.stats` | 页面示例：事件统计 | 无 | 返回本插件收到的事件快照（用来展示「钩子真的被调用了」） |
| `pagedemo.refresh` | 页面示例：刷新计数 | 无 | 清空本插件记录的事件计数（工具栏按钮用它演示 menus 扩展点） |

插件自有接口 `GET /api/plugins/xwork.page-demo/x/stats`：**整页 `page.html` 与首页面板
`panel.html` 都靠它取数**，返回事件列表、三个自配置项的当前值，以及
`state`（activations / heartbeats / last_beat）。页面与面板都兼容两种通道：主壳注入的
`window.xwork.api`，或 iframe URL 自带的 `?t=` token（首次加载早于运行时注入时的兜底）。

三个自配置项都可在插件详情里改，改完页面下次刷新（或自动刷新）即生效：

| 设置项 | 默认 | 作用 |
|---|---|---|
| `greeting` | `你好，运维同学` | 整页顶部与面板摘要里的问候语 |
| `showCount` | `true` | 关掉后隐藏「保存次数」卡片与最近事件列表，面板也只留统计摘要 |
| `refreshMs` | `3000` | 页面与面板的自动刷新间隔（毫秒，页面内钳制到 1000–60000） |

## 用到的扩展点

| 扩展点 | 本插件的声明 |
|---|---|
| `contributes.pages` | `main` → `page.html`，插件自己的整页 |
| `contributes.panels` | `home-saves` → `panel.html`，slot `home` |
| `contributes.menus` | `files-refresh`，位置 `page.toolbar`，页面 `files` |
| `contributes.hooks` | `file.saved` → 模块顶层 `on_file_saved()` |
| `contributes.settings` | `greeting` / `showCount` / `refreshMs` |
| `api.route` | `GET /x/stats` |
| `api.every` | `heartbeat`，每 60s 累加一次心跳 |
| `api.on_activate` / `on_deactivate` | 累计激活次数、记录停用 |

## 权限与安全

只申请 `ui.inject`（修改界面）：往首页嵌面板、往文件页加按钮。嵌入内容隔离在
iframe 里，拿到的是插件自己的 token，读不到主界面的 DOM。它只订阅 `file.saved`
钩子做内存记账（只留最近 20 条，重启即清空，不落盘）；定时任务随停用停止；不联网、不写文件。

## 文件

- `manifest.json`：清单，声明页面、面板、工具栏按钮、钩子、设置项与权限。
- `backend.py`：全部实现，含生命周期回调、定时任务、自有接口、事件快照与两个命令。
- `page.html` / `panel.html` / `style.css`：独立页面、首页面板与共用样式（支持浅色/深色）。
