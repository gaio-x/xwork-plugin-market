/* 壁纸设置页脚本。
 *
 * 运行位置：设置弹窗里的 iframe，与主程序同源。三件事按顺序说清楚：
 *   1. 鉴权 —— iframe 入口 URL 带 ?t=token；fetch 走 X-WB-Token 头，
 *      <img>/<video>/<link> 带不了头发，只能走 ?t=（主程序中间件两种都认）。
 *   2. 上传 —— 走主程序的媒体路由（原始字节，不再 base64），落地文件由主程序写盘。
 *      插件进程里没有删文件的能力，所以删除时它只回 delete_url，由本页逐个 DELETE。
 *   3. 重画 —— 改完调 notifyShell()：给父窗口派发 xwork:bg-refresh，
 *      注入脚本据此立刻重画背景，不必等它 3 秒一次的轮询。
 *
 * 文件选择用浏览器原生 <input type="file">：主程序那条选文件接口是服务端阻塞式对话框，
 * 要在 iframe 里轮询等结果，实测点了没反应，所以这里不碰它。
 */

"use strict";

const PID = "xwork.bg-image";
const TOKEN = new URLSearchParams(location.search).get("t") || "";
const OWN = `/api/plugins/${PID}/x/`;
const MEDIA = `/api/plugins/${PID}/media`;

const CROP_MAX_W = 2560;    // 导出宽度上限：超出等比缩，避免一张巨图拖慢主界面合成
const CROP_MIN_PX = 32;     // 裁剪框最小边长（屏幕像素）
const CROP_PREVIEW_W = 160; // 预览画布固定宽
const CROP_PREVIEW_MIN_H = 60;   // 预览画布高度下限（太扁就画不出东西）
const CROP_PREVIEW_MAX_H = 160;  // 预览画布高度上限（别把卡片撑高）
// 预览列占的横向空间：宽度 + 间距 + 边框，算画布最大宽度时要先扣掉
const CROP_SIDE_W = CROP_PREVIEW_W + 30;

const el = {
  nowThumb: document.getElementById("now-thumb"),
  nowName: document.getElementById("now-name"),
  nowHint: document.getElementById("now-hint"),
  clear: document.getElementById("clear"),
  presets: document.getElementById("presets"),
  library: document.getElementById("library"),
  pickImage: document.getElementById("pick-image"),
  pickVideo: document.getElementById("pick-video"),
  fileImage: document.getElementById("file-image"),
  fileVideo: document.getElementById("file-video"),
  uploadHint: document.getElementById("upload-hint"),
  mask: document.getElementById("mask"),
  maskVal: document.getElementById("mask-val"),
  fit: document.getElementById("fit"),
  status: document.getElementById("status"),
  crop: document.getElementById("crop"),
  cropCanvas: document.getElementById("crop-canvas"),
  cropInfo: document.getElementById("crop-info"),
  cropOk: document.getElementById("crop-ok"),
  cropCancel: document.getElementById("crop-cancel"),
  cropX: document.getElementById("crop-x"),
  cropRatios: document.getElementById("crop-ratios"),
  cropPreview: document.getElementById("crop-preview"),
};

let current = blankState();
let presets = [];
let presetsError = "";
let libraryItems = [];
let fitReady = false;
// 删除是两步确认：第一次点变成"确认删除"，3.5 秒内再点才真删。
// 不用 window.confirm：插件页的 iframe 没有 allow-modals，原生确认框会被静默挡掉。
let armedUrl = "";
let armedTimer = 0;

function blankState() {
  return {
    mode: "none", preset: "", preset_name: "", preset_css: "",
    media_url: "", media_name: "", media_kind: "",
    mask: 30, fit: "cover", rev: "", error: "",
  };
}

/* ---------------- 传输 ---------------- */

async function request(url, method, body) {
  const res = await fetch(url, {
    method,
    cache: "no-store",
    headers: { "X-WB-Token": TOKEN, "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((json && (json.detail || json.error)) || `HTTP ${res.status}`);
  return (json && json.data) || null;
}

/** 调本插件自己的 /x/ 接口。主壳注入了 xwork.api 就用它（自动带 token），否则直连。 */
function own(method, path, body) {
  if (window.xwork && typeof window.xwork.api === "function") {
    return Promise.resolve(window.xwork.api(method, OWN + path, body))
      .then((r) => (r && r.data) || null);
  }
  return request(OWN + path, method, body);
}

/** 上传原始字节。返回 {name, url, bytes, kind}，url 形如 /api/plugins/<id>/media/<name>。 */
async function upload(blobOrFile, filename) {
  const res = await fetch(`${MEDIA}?name=${encodeURIComponent(filename)}`, {
    method: "POST",
    headers: { "X-WB-Token": TOKEN, "Content-Type": "application/octet-stream" },
    body: blobOrFile,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((json && (json.detail || json.error)) || `HTTP ${res.status}`);
  return (json && json.data) || null;
}

/** <img>/<video> 带不了自定义头，媒体地址只能把 token 拼在 query 上。 */
function withToken(url) {
  if (!url) return "";
  const sep = url.indexOf("?") >= 0 ? "&" : "?";
  return `${url}${sep}t=${encodeURIComponent(TOKEN)}`;
}

/** 让主界面立刻重画。CustomEvent 是同源主通道，postMessage 是父页换实现时的兜底。 */
function notifyShell() {
  try {
    window.parent.dispatchEvent(new CustomEvent("xwork:bg-refresh"));
  } catch (e) { /* 跨源或沙箱挡住：postMessage + 轮询会在 3 秒内追上 */ }
  try {
    window.parent.postMessage({ type: "xwork:bg-refresh" }, "*");
  } catch (e) { /* 同上 */ }
}

/* ---------------- 小工具 ---------------- */

function clamp(v, lo, hi) {
  return Math.min(hi, Math.max(lo, v));
}

function fmtBytes(bytes) {
  const v = Number(bytes) || 0;
  if (v <= 0) return "大小未知";
  if (v < 1024) return `${v} B`;
  if (v < 1024 * 1024) return `${Math.round(v / 1024)} KB`;
  if (v < 1024 * 1024 * 1024) return `${(v / 1024 / 1024).toFixed(1)} MB`;
  return `${(v / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

/** 主程序只接受 [A-Za-z0-9._-] 的文件名，所以时间戳 + 英文前缀，绝不带中文。 */
function stamp() {
  const d = new Date();
  const pad = (n, w) => String(n).padStart(w || 2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`
    + `-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`
    + `${pad(d.getMilliseconds(), 3)}`;
}

function extOf(name) {
  const parts = String(name || "").split(".");
  if (parts.length < 2) return "";
  return (parts.pop() || "").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 5);
}

let toastTimer = 0;
function toast(text, kind) {
  let node = document.getElementById("bg-toast");
  if (!node) {
    node = document.createElement("div");
    node.id = "bg-toast";
    document.body.appendChild(node);
  }
  node.className = `toast ${kind || ""}`.trim();
  node.textContent = text;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { node.remove(); }, 3200);
}

function mutedLine(box, text) {
  const div = document.createElement("div");
  div.className = "muted";
  div.textContent = text;
  box.appendChild(div);
}

/** 跟随主程序的主题：iframe 是独立文档，父页的 data-theme 不会自己传进来。 */
function syncTheme() {
  let theme = "";
  try {
    theme = window.parent.document.documentElement.getAttribute("data-theme") || "";
  } catch (e) { return; }
  const root = document.documentElement;
  if (theme) root.setAttribute("data-theme", theme);
  else root.removeAttribute("data-theme");
}

function watchTheme() {
  try {
    const target = window.parent.document.documentElement;
    new MutationObserver(syncTheme).observe(target, {
      attributes: true, attributeFilter: ["data-theme"],
    });
  } catch (e) {
    setInterval(syncTheme, 2000);      // 拿不到父文档时退回轮询，代价可忽略
  }
}

/* ---------------- 渲染 ---------------- */

function normalise(state) {
  return Object.assign(blankState(), state || {});
}

function paintNow(state) {
  const box = el.nowThumb;
  box.innerHTML = "";
  box.style.backgroundImage = "";
  box.style.backgroundColor = "";

  let title = "当前没有壁纸";
  let detail = "界面使用默认纯色背景";

  if (state.mode === "preset") {
    title = `内置壁纸 · ${state.preset_name || state.preset}`;
    detail = "纯 CSS 渐变，不占磁盘";
    box.style.backgroundColor = "var(--surface-2)";
    if (state.preset_css) box.style.backgroundImage = state.preset_css;
  } else if (state.mode === "image" || state.mode === "video") {
    const isVideo = state.mode === "video";
    title = state.media_name || (isVideo ? "本地视频" : "本地图片");
    detail = `${isVideo ? "视频" : "图片"} · 以文件形式保存在本机`;
    const node = document.createElement(isVideo ? "video" : "img");
    node.src = withToken(state.media_url);
    if (isVideo) {
      node.muted = true;
      node.loop = true;
      node.playsInline = true;
      node.preload = "metadata";
    } else {
      node.alt = "";
    }
    box.appendChild(node);
  }

  el.nowName.textContent = title;
  el.nowHint.textContent = detail;
  el.clear.disabled = state.mode === "none";
}

function paintPresets() {
  el.presets.innerHTML = "";
  if (!presets.length) {
    mutedLine(el.presets, presetsError
      ? `内置壁纸读取失败：${presetsError}`
      : "没有可用的内置壁纸，可用下面的图片或视频代替");
    return;
  }
  const frag = document.createDocumentFragment();
  for (const p of presets) {
    const tile = document.createElement("button");
    tile.type = "button";
    tile.className = "bg-tile";
    tile.dataset.id = p.id;
    tile.title = p.name;
    // backgroundImage 而不是 background：简写会连带清掉其它背景属性，
    // 而且写错时整条声明被丢弃、格子变成一片空白 —— 所以另给一层兜底色。
    tile.style.backgroundColor = "var(--surface-2)";
    if (p.css) tile.style.backgroundImage = p.css;
    const on = current.mode === "preset" && current.preset === p.id;
    tile.setAttribute("aria-pressed", on ? "true" : "false");
    if (on) tile.classList.add("on");
    const name = document.createElement("span");
    name.className = "bg-tile-name";
    name.textContent = p.name;
    tile.appendChild(name);
    tile.addEventListener("click", () => applyPreset(p));
    frag.appendChild(tile);
  }
  el.presets.appendChild(frag);
}

function paintLibrary() {
  el.library.innerHTML = "";
  if (!libraryItems.length) {
    mutedLine(el.library, "还没有保存的图片或视频。选一张图片、一段视频试试。");
    return;
  }
  const frag = document.createDocumentFragment();
  for (const item of libraryItems) {
    const isVideo = item.kind === "video";
    const row = document.createElement("div");
    row.className = "bg-lib-row";
    if (item.active) row.classList.add("on");

    const thumb = document.createElement("div");
    thumb.className = "bg-lib-thumb";
    if (isVideo) {
      const video = document.createElement("video");
      video.src = `${withToken(item.url)}#t=0.1`;   // 取第 0.1 秒当封面
      video.muted = true;
      video.preload = "metadata";
      thumb.appendChild(video);
      const badge = document.createElement("span");
      badge.className = "bg-lib-kind";
      badge.textContent = "视频";
      thumb.appendChild(badge);
    } else {
      const img = document.createElement("img");
      img.src = withToken(item.url);
      img.alt = "";
      img.loading = "lazy";
      thumb.appendChild(img);
    }

    const meta = document.createElement("div");
    meta.className = "bg-lib-meta";
    const name = document.createElement("div");
    name.className = "bg-lib-name";
    name.textContent = item.name;
    name.title = item.name;
    const sub = document.createElement("div");
    sub.className = "hint";
    sub.textContent = `${isVideo ? "视频" : "图片"} · ${fmtBytes(item.bytes)}`;
    meta.appendChild(name);
    meta.appendChild(sub);

    const acts = document.createElement("div");
    acts.className = "row";
    const applyBtn = document.createElement("button");
    applyBtn.className = "btn sm";
    applyBtn.dataset.act = "apply";
    applyBtn.dataset.url = item.url;
    applyBtn.textContent = item.active ? "使用中" : "应用";
    applyBtn.disabled = !!item.active;
    const delBtn = document.createElement("button");
    delBtn.className = "btn sm danger";
    delBtn.dataset.act = "del";
    delBtn.dataset.url = item.url;
    delBtn.dataset.name = item.name;
    delBtn.textContent = armedUrl && armedUrl === item.url ? "确认删除" : "删除";
    delBtn.title = "删除时同步删掉本机的落地文件";
    acts.appendChild(applyBtn);
    acts.appendChild(delBtn);

    row.appendChild(thumb);
    row.appendChild(meta);
    row.appendChild(acts);
    frag.appendChild(row);
  }
  el.library.appendChild(frag);
}

function paintControls(state) {
  el.mask.value = String(state.mask);
  el.maskVal.textContent = `${state.mask}%`;
  if (fitReady) el.fit.value = state.fit;
}

function setStatus(state) {
  el.status.classList.remove("warn");
  if (state.error) {
    el.status.classList.add("warn");
    el.status.textContent = state.error;
    return;
  }
  if (state.mode === "preset") {
    el.status.textContent = `正在使用内置壁纸「${state.preset_name}」，遮罩 ${state.mask}%。`;
  } else if (state.mode === "image" || state.mode === "video") {
    el.status.textContent = `正在使用${state.mode === "video" ? "视频" : "图片"} `
      + `${state.media_name}，遮罩 ${state.mask}%。`;
  } else {
    el.status.textContent = "当前没有壁纸，界面使用默认纯色背景。";
  }
}

function render(state, opts) {
  const options = opts || {};
  current = normalise(state);
  paintNow(current);
  paintControls(current);
  paintPresets();
  if (options.library !== false) paintLibrary();
  setStatus(current);
}

/* ---------------- 动作 ---------------- */

function setBusy(busy, text) {
  el.pickImage.disabled = busy;
  el.pickVideo.disabled = busy;
  el.uploadHint.textContent = text || "";
}

async function uploadAndApply(blob, filename) {
  setBusy(true, "正在保存到本机…");
  try {
    const data = await upload(blob, filename);
    if (!data || !data.url) throw new Error("上传接口没有返回文件地址");
    const state = await own("POST", "apply", {
      mediaUrl: data.url, mediaName: data.name, mediaBytes: data.bytes,
    });
    await refreshLibrary();
    render(state || current);
    notifyShell();
    return state;
  } finally {
    setBusy(false, "");
  }
}

async function applyPreset(preset) {
  try {
    const state = await own("POST", "apply", { preset: preset.id });
    await refreshLibrary();
    render(state || current);
    notifyShell();
    toast(`已应用「${preset.name}」`, "ok");
  } catch (e) {
    toast(`应用失败：${e.message}`, "error");
  }
}

async function applyMedia(url) {
  try {
    const state = await own("POST", "apply", { mediaUrl: url });
    await refreshLibrary();
    render(state || current);
    notifyShell();
    toast("已设为壁纸", "ok");
  } catch (e) {
    toast(`应用失败：${e.message}`, "error");
  }
}

async function clearWallpaper() {
  try {
    const state = await own("POST", "apply", { clear: true });
    render(state || current);
    notifyShell();
    toast("已恢复默认背景", "ok");
  } catch (e) {
    toast(`恢复失败：${e.message}`, "error");
  }
}

/** 删除的第一步：把按钮切成"确认删除"，等第二次点击。 */
function armDelete(item) {
  clearTimeout(armedTimer);
  if (armedUrl === item.url) {
    armedUrl = "";
    removeItem(item);
    return;
  }
  armedUrl = item.url;
  paintLibrary();
  armedTimer = setTimeout(() => {
    armedUrl = "";
    paintLibrary();
  }, 3500);
}

/** 删除：先从清单移除（x/remove），再逐个 DELETE 落地文件 —— 插件进程删不了文件。 */
async function removeItem(item) {
  clearTimeout(armedTimer);
  armedUrl = "";
  try {
    const data = await own("POST", "remove", { url: item.url });
    const files = (data && Array.isArray(data.files)) ? data.files : [];
    let failed = 0;
    for (const file of files) {
      const target = file.delete_url || file.url;
      if (!target) { failed += 1; continue; }
      try {
        const res = await fetch(target, {
          method: "DELETE",
          headers: { "X-WB-Token": TOKEN },
        });
        if (!res.ok && res.status !== 404) failed += 1;   // 404 = 已经没了，不算失败
      } catch (e) {
        failed += 1;
      }
    }
    if (data && data.state) current = normalise(data.state);
    if (data && data.library && Array.isArray(data.library.items)) libraryItems = data.library.items;
    else await refreshLibrary();
    render(current);
    notifyShell();
    if (!files.length) {
      toast("已从列表移除，但没有拿到落地文件路径，磁盘上的文件需要手动清理", "error");
    } else if (failed) {
      toast(`已移除，但有 ${failed} 个落地文件删除失败`, "error");
    } else {
      toast("已删除，落地文件同步清理", "ok");
    }
  } catch (e) {
    toast(`删除失败：${e.message}`, "error");
  }
}

/* ---------------- 读取 ---------------- */

async function loadPresets() {
  try {
    const info = await own("GET", "presets");
    presets = (info && Array.isArray(info.items)) ? info.items : [];
    presetsError = presets.length ? "" : "接口没有返回任何壁纸";
    if (info && Array.isArray(info.mask_range) && info.mask_range.length === 2) {
      el.mask.min = String(info.mask_range[0]);
      el.mask.max = String(info.mask_range[1]);
    }
    fillFitOptions(info && info.fit_options);
  } catch (e) {
    presets = [];
    presetsError = e.message;
  }
  paintPresets();
}

function fillFitOptions(options) {
  el.fit.innerHTML = "";
  if (!Array.isArray(options) || !options.length) {
    el.fit.disabled = true;
    fitReady = false;
    return;
  }
  for (const opt of options) {
    const node = document.createElement("option");
    node.value = opt.value;
    node.textContent = opt.label || opt.value;
    el.fit.appendChild(node);
  }
  el.fit.disabled = false;
  fitReady = true;
}

async function loadState() {
  try {
    const state = await own("GET", "state");
    if (!state) throw new Error("接口没有返回状态");
    render(state, { library: false });
    return true;
  } catch (e) {
    el.status.classList.add("warn");
    el.status.textContent = `壁纸接口不可用：${e.message}`;
    return false;
  }
}

async function refreshLibrary() {
  try {
    const data = await own("GET", "library");
    libraryItems = (data && Array.isArray(data.items)) ? data.items : [];
  } catch (e) {
    libraryItems = [];
    el.library.innerHTML = "";
    mutedLine(el.library, `已保存壁纸读取失败：${e.message}`);
    return;
  }
  paintLibrary();
}

/* ---------------- 选择文件 ---------------- */

function readAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("文件读取失败"));
    reader.readAsDataURL(file);
  });
}

async function onPickImage() {
  const file = el.fileImage.files && el.fileImage.files[0];
  el.fileImage.value = "";     // 清空：同一个文件也要能再选一次、再触发 change
  if (!file) return;
  el.uploadHint.textContent = "";
  try {
    const dataUrl = await readAsDataURL(file);
    openCrop(dataUrl);
  } catch (e) {
    toast(`读取图片失败：${e.message}`, "error");
  }
}

async function onPickVideo() {
  const file = el.fileVideo.files && el.fileVideo.files[0];
  el.fileVideo.value = "";
  if (!file) return;
  const ext = extOf(file.name) || "mp4";
  try {
    await uploadAndApply(file, `wallpaper-${stamp()}.${ext}`);
    toast("视频已保存并设为壁纸", "ok");
  } catch (e) {
    toast(`上传失败：${e.message}`, "error");
  }
}

/* ---------------- 裁剪弹窗 ---------------- */

/**
 * 比例选项。id 与 page.html 里按钮上的 data-ratio 一一对应：
 *   window —— 跟随窗口，取 iframe 自身的 innerWidth / innerHeight（= 壁纸铺满时的实际比例），
 *             也是本弹窗的**默认值**；
 *   "16:9" 这类 —— 固定比例；
 *   free    —— 不约束。
 */
const CROP_RATIOS = ["window", "16:9", "16:10", "4:3", "3:2", "1:1", "free"];
const CROP_RATIO_DEFAULT = "window";

const crop = {
  img: null,
  dispW: 0,
  dispH: 0,
  scale: 1,                                  // 显示像素 / 原图像素
  sel: { x: 0, y: 0, w: 0, h: 0 },           // 选区，单位是显示像素
  drag: null,                                // {mode, ox, oy, base}
  busy: false,
  ratioMode: CROP_RATIO_DEFAULT,             // 当前比例选项 id
  previewRaf: 0,                             // 预览重绘的 rAF 句柄（0 = 没有待办）
};

/** 比例 id → 宽高比数值；free 或数据有问题时返回 0（表示不约束）。 */
function ratioValue(mode) {
  if (mode === "window") {
    // 跟随窗口：每次现算，窗口尺寸变了比例也跟着变，不需要缓存
    const w = window.innerWidth;
    const h = window.innerHeight;
    if (!w || !h || w <= 0 || h <= 0) return 16 / 9;   // 视口还没量出来时的兜底
    return w / h;
  }
  if (!mode || mode === "free") return 0;
  const parts = String(mode).split(":");
  if (parts.length !== 2) return 0;
  const w = Number(parts[0]);
  const h = Number(parts[1]);
  if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return 0;
  return w / h;
}

/** 当前生效的比例数值（0 = 自由）。 */
function currentRatio() {
  return ratioValue(crop.ratioMode);
}

/** 把比例按钮的选中态刷成 crop.ratioMode；复用主程序 .seg-btn 的 aria-pressed 选中样式。 */
function paintCropRatios() {
  if (!el.cropRatios) return;
  el.cropRatios.querySelectorAll("[data-ratio]").forEach((btn) => {
    btn.setAttribute("aria-pressed", btn.dataset.ratio === crop.ratioMode ? "true" : "false");
  });
}

/** 尺寸不变，只把框挪回图片范围内。 */
function fitInside(sel) {
  const w = Math.min(sel.w, crop.dispW);
  const h = Math.min(sel.h, crop.dispH);
  return {
    x: clamp(sel.x, 0, Math.max(0, crop.dispW - w)),
    y: clamp(sel.y, 0, Math.max(0, crop.dispH - h)),
    w,
    h,
  };
}

/**
 * 以 (cx, cy) 为中心、按 ratio 取一个宽尽量接近 wantW 的框，并夹进图片范围。
 * 图片比框还小时先按高收、再按宽收，保证结果一定落在图片内。
 */
function centeredRatioBox(cx, cy, ratio, wantW) {
  let w = Math.max(CROP_MIN_PX, wantW);
  let h = w / ratio;
  if (h > crop.dispH) { h = crop.dispH; w = h * ratio; }
  if (w > crop.dispW) { w = crop.dispW; h = w / ratio; }
  return fitInside({ x: cx - w / 2, y: cy - h / 2, w, h });
}

/**
 * 从锚点 (ax, ay) 朝 (dirX, dirY) 方向拉出一个比例为 ratio 的框。
 * 用于「空白处重新拉框」与各类手柄缩放：锚点一侧固定不动，指针决定大小。
 */
function boxFromAnchor(ax, ay, dirX, dirY, wantW, ratio) {
  const maxW = dirX > 0 ? crop.dispW - ax : ax;
  const maxH = dirY > 0 ? crop.dispH - ay : ay;
  let w = Math.max(CROP_MIN_PX, wantW);
  let h = w / ratio;
  if (h > maxH) { h = Math.max(1, maxH); w = h * ratio; }   // 顶到纵向边界：按高收回
  if (w > maxW) { w = Math.max(1, maxW); h = w / ratio; }   // 再顶到横向边界：按宽收回
  return {
    x: dirX > 0 ? ax : ax - w,
    y: dirY > 0 ? ay : ay - h,
    w,
    h,
  };
}

/** 手柄缩放：把指针位置换算成"锚点 + 比例"的框。角手柄两个方向都动，边手柄只动一边。 */
function ratioFromHandle(mode, base, point, ratio) {
  const west = mode.indexOf("w") >= 0;
  const east = mode.indexOf("e") >= 0;
  const north = mode.indexOf("n") >= 0;
  const south = mode.indexOf("s") >= 0;

  // 角手柄：锚在对角，宽由指针的横向位移驱动
  if ((west || east) && (north || south)) {
    const ax = west ? base.x + base.w : base.x;
    const ay = north ? base.y + base.h : base.y;
    return boxFromAnchor(ax, ay, east ? 1 : -1, south ? 1 : -1,
      Math.abs(point.x - ax), ratio);
  }
  // 左右手柄：宽由指针驱动，高以原选区中线上下对称
  if (west || east) {
    const ax = west ? base.x + base.w : base.x;
    // 纵向可用空间取整张画布高度（下面会把框重新在旧选区中线上居中），
    // 若按 base.y 起算，靠下的选区会被提前收窄，手柄会"拖不动"。
    const box = boxFromAnchor(ax, 0, west ? -1 : 1, 1,
      Math.abs(point.x - ax), ratio);
    box.y = clamp(base.y + (base.h - box.h) / 2, 0, Math.max(0, crop.dispH - box.h));
    return box;
  }
  // 上下手柄：高由指针驱动（换算成宽），宽以原选区中线左右对称
  const ay = north ? base.y + base.h : base.y;
  const wantH = Math.max(CROP_MIN_PX, Math.abs(point.y - ay));
  // 横向可用空间同理取整张画布宽度，居中留给下面那一步
  const box = boxFromAnchor(0, ay, 1, north ? -1 : 1, wantH * ratio, ratio);
  box.x = clamp(base.x + (base.w - box.w) / 2, 0, Math.max(0, crop.dispW - box.w));
  return box;
}

/** 切换比例：以当前选区中心为锚点按新比例重算宽高，并夹在图片范围内。 */
function setCropRatio(mode) {
  if (CROP_RATIOS.indexOf(mode) < 0) return;
  crop.ratioMode = mode;
  paintCropRatios();
  if (!crop.img) return;                     // 图还没解出来：只记住选择，openCrop 会用它

  const ratio = currentRatio();
  if (!ratio) {                              // 自由：选区保持原样
    drawCrop();
    updateCropInfo();
    scheduleCropPreview();
    return;
  }
  const s = crop.sel;
  const cx = s.x + s.w / 2;
  const cy = s.y + s.h / 2;
  crop.sel = centeredRatioBox(cx, cy, ratio, Math.max(CROP_MIN_PX, s.w));
  drawCrop();
  updateCropInfo();
  scheduleCropPreview();
}

function openCrop(dataUrl) {
  const img = new Image();
  img.onload = () => {
    crop.img = img;
    // 每次打开都回到软件默认比例（跟随窗口），避免上次选的 1:1 悄悄影响这次
    crop.ratioMode = CROP_RATIO_DEFAULT;
    paintCropRatios();
    layoutCrop();
    resetSelection();
    el.crop.hidden = false;
    lockScroll(true);
    drawCrop();
    updateCropInfo();
    drawCropPreview();
    el.cropOk.focus();
  };
  img.onerror = () => {
    toast("这张图片无法解码，换一张试试", "error");
  };
  img.src = dataUrl;
}

function layoutCrop() {
  const img = crop.img;
  // 弹窗在 iframe 里，尺寸按 iframe 视口算；留出标题栏、比例行与按钮行的空间，
  // 并扣掉右侧预览列的宽度（否则横向会被挤出滚动条，画布反而变小）
  const maxW = Math.max(240, Math.min(window.innerWidth - 60 - CROP_SIDE_W, 860));
  const maxH = Math.max(160, Math.min(window.innerHeight - 240, 430));
  crop.scale = Math.min(maxW / img.naturalWidth, maxH / img.naturalHeight, 1);
  crop.dispW = Math.max(1, Math.round(img.naturalWidth * crop.scale));
  crop.dispH = Math.max(1, Math.round(img.naturalHeight * crop.scale));

  const dpr = window.devicePixelRatio || 1;
  el.cropCanvas.width = Math.round(crop.dispW * dpr);
  el.cropCanvas.height = Math.round(crop.dispH * dpr);
  el.cropCanvas.style.width = `${crop.dispW}px`;
  el.cropCanvas.style.height = `${crop.dispH}px`;
}

function resetSelection() {
  const ratio = currentRatio();
  if (ratio) {
    // 默认框占图片 86%，但必须守住当前比例
    const wantW = Math.max(CROP_MIN_PX, Math.round(crop.dispW * 0.86));
    crop.sel = centeredRatioBox(crop.dispW / 2, crop.dispH / 2, ratio, wantW);
    return;
  }
  const w = Math.max(CROP_MIN_PX, Math.round(crop.dispW * 0.86));
  const h = Math.max(CROP_MIN_PX, Math.round(crop.dispH * 0.86));
  crop.sel = {
    x: Math.round((crop.dispW - w) / 2),
    y: Math.round((crop.dispH - h) / 2),
    w: Math.min(w, crop.dispW),
    h: Math.min(h, crop.dispH),
  };
}

function handlePoints() {
  const s = crop.sel;
  return [
    { name: "nw", x: s.x, y: s.y },
    { name: "ne", x: s.x + s.w, y: s.y },
    { name: "se", x: s.x + s.w, y: s.y + s.h },
    { name: "sw", x: s.x, y: s.y + s.h },
    { name: "n", x: s.x + s.w / 2, y: s.y },
    { name: "e", x: s.x + s.w, y: s.y + s.h / 2 },
    { name: "s", x: s.x + s.w / 2, y: s.y + s.h },
    { name: "w", x: s.x, y: s.y + s.h / 2 },
  ];
}

function drawCrop() {
  const img = crop.img;
  if (!img) return;
  const dpr = window.devicePixelRatio || 1;
  const ctx = el.cropCanvas.getContext("2d");
  const s = crop.sel;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, crop.dispW, crop.dispH);
  ctx.drawImage(img, 0, 0, crop.dispW, crop.dispH);

  // 选区之外压暗：evenodd 让两个矩形只留下中间那块
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, crop.dispW, crop.dispH);
  ctx.rect(s.x, s.y, s.w, s.h);
  ctx.fillStyle = "rgba(16, 24, 40, .55)";
  ctx.fill("evenodd");
  ctx.restore();

  // 三分线：只看比例时有用，不挡视线
  ctx.save();
  ctx.strokeStyle = "rgba(255, 255, 255, .35)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let i = 1; i <= 2; i += 1) {
    const x = s.x + (s.w * i) / 3;
    const y = s.y + (s.h * i) / 3;
    ctx.moveTo(x, s.y);
    ctx.lineTo(x, s.y + s.h);
    ctx.moveTo(s.x, y);
    ctx.lineTo(s.x + s.w, y);
  }
  ctx.stroke();
  ctx.restore();

  // 边框 + 8 个手柄（四角 + 四边）
  ctx.save();
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 1.5;
  ctx.strokeRect(s.x + 0.5, s.y + 0.5, Math.max(0, s.w - 1), Math.max(0, s.h - 1));
  for (const point of handlePoints()) {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(point.x - 4, point.y - 4, 8, 8);
    ctx.strokeStyle = "rgba(16, 24, 40, .55)";
    ctx.lineWidth = 1;
    ctx.strokeRect(point.x - 4, point.y - 4, 8, 8);
  }
  ctx.restore();
}

function updateCropInfo() {
  const s = crop.sel;
  const ow = Math.max(1, Math.round(s.w / crop.scale));
  const oh = Math.max(1, Math.round(s.h / crop.scale));
  const scaled = ow > CROP_MAX_W
    ? `，保存为 ${CROP_MAX_W} × ${Math.max(1, Math.round((oh * CROP_MAX_W) / ow))}`
    : "";
  el.cropInfo.textContent = `选区 ${ow} × ${oh} 像素${scaled}`;
}

/* ---------------- 右上角预览 ---------------- */

/**
 * 预览重绘走 rAF 节流：pointermove 一秒能来上百次，每次都把原图那块重画一遍会很卡，
 * 而一个动画帧最多只需要一帧结果。crop.previewRaf 非 0 说明本帧已有待办，直接返回。
 */
function scheduleCropPreview() {
  if (crop.previewRaf) return;
  if (typeof requestAnimationFrame !== "function") {   // 极端老内核：退化成同步重绘
    drawCropPreview();
    return;
  }
  crop.previewRaf = requestAnimationFrame(() => {
    crop.previewRaf = 0;
    drawCropPreview();
  });
}

/**
 * 画"应用之后会得到的那张图"：直接把原图上选区覆盖的那块按目标尺寸画出来。
 * 画布尺寸按选区比例自适应（宽固定 160，高 = 160 × 选区高/宽，夹在 60~160），
 * 所以预览永远是等比缩小的结果，不会变形。
 */
function drawCropPreview() {
  const canvas = el.cropPreview;
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const img = crop.img;
  const s = crop.sel;
  const valid = !!img && s.w >= CROP_MIN_PX && s.h >= CROP_MIN_PX;

  const width = CROP_PREVIEW_W;
  const rawH = valid ? (width * s.h) / Math.max(1, s.w) : width * 0.6;
  const height = Math.round(clamp(rawH, CROP_PREVIEW_MIN_H, CROP_PREVIEW_MAX_H));

  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(width * dpr);
  canvas.height = Math.round(height * dpr);
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);

  // 主题色从主程序变量里取，深浅主题都不用另配一套
  const css = getComputedStyle(document.documentElement);
  const muted = (css.getPropertyValue("--text-3") || "").trim() || "#8b929e";
  const backdrop = (css.getPropertyValue("--surface-2") || "").trim() || "#fafbfc";

  if (!valid) {
    // 选区无效时给一句提示而不是留一块空白 —— 空白看起来像"预览坏了"
    ctx.fillStyle = backdrop;
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = muted;
    ctx.font = "11px 'Segoe UI', 'Microsoft YaHei', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("选择区域太小", width / 2, height / 2);
    return;
  }

  // 显示像素 → 原图像素，与 exportSelection() 同一套换算，保证"预览即所得"
  const scale = crop.scale || 1;
  const sx = clamp(Math.round(s.x / scale), 0, Math.max(0, img.naturalWidth - 1));
  const sy = clamp(Math.round(s.y / scale), 0, Math.max(0, img.naturalHeight - 1));
  const sw = Math.min(Math.max(1, Math.round(s.w / scale)), img.naturalWidth - sx);
  const sh = Math.min(Math.max(1, Math.round(s.h / scale)), img.naturalHeight - sy);

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, width, height);
}

function canvasPoint(event) {
  const rect = el.cropCanvas.getBoundingClientRect();
  const sx = rect.width ? crop.dispW / rect.width : 1;
  const sy = rect.height ? crop.dispH / rect.height : 1;
  return {
    x: (event.clientX - rect.left) * sx,
    y: (event.clientY - rect.top) * sy,
  };
}

function hitHandle(point) {
  const reach = 10;
  for (const handle of handlePoints()) {          // 角在前，边在后：优先级更高
    if (Math.abs(point.x - handle.x) <= reach && Math.abs(point.y - handle.y) <= reach) {
      return handle.name;
    }
  }
  return "";
}

function insideSelection(point) {
  const s = crop.sel;
  return point.x >= s.x && point.x <= s.x + s.w && point.y >= s.y && point.y <= s.y + s.h;
}

function updateCursor(point) {
  const handle = hitHandle(point);
  const map = {
    nw: "nwse-resize", se: "nwse-resize", ne: "nesw-resize", sw: "nesw-resize",
    n: "ns-resize", s: "ns-resize", e: "ew-resize", w: "ew-resize",
  };
  el.cropCanvas.style.cursor = handle ? map[handle] : (insideSelection(point) ? "move" : "crosshair");
}

function onCropDown(event) {
  if (!crop.img || crop.busy) return;
  const point = canvasPoint(event);
  const handle = hitHandle(point);
  const ratio = currentRatio();

  if (!handle && !insideSelection(point)) {
    // 空白处按下 = 从这一点重新拉框，比"只能拖手柄"顺手；
    // 有比例约束时先给一个守住比例的最小框，之后拖动再按比例展开。
    crop.drag = { mode: "new", ox: point.x, oy: point.y, base: { x: point.x, y: point.y, w: 0, h: 0 } };
    crop.sel = ratio
      ? boxFromAnchor(point.x, point.y, 1, 1, CROP_MIN_PX, ratio)
      : { x: point.x, y: point.y, w: CROP_MIN_PX, h: CROP_MIN_PX };
    el.cropCanvas.setPointerCapture(event.pointerId);
    drawCrop();
    updateCropInfo();
    scheduleCropPreview();
    event.preventDefault();
    return;
  }

  crop.drag = {
    mode: handle || "move",
    ox: point.x,
    oy: point.y,
    base: { x: crop.sel.x, y: crop.sel.y, w: crop.sel.w, h: crop.sel.h },
  };
  el.cropCanvas.setPointerCapture(event.pointerId);
  event.preventDefault();
}

function onCropMove(event) {
  if (!crop.img) return;
  const point = canvasPoint(event);
  const drag = crop.drag;
  if (!drag) {
    updateCursor(point);
    return;
  }
  const base = drag.base;
  const dx = point.x - drag.ox;
  const dy = point.y - drag.oy;
  const ratio = currentRatio();      // 0 = 自由：走原来的自由拉框逻辑
  let sel;

  if (drag.mode === "move") {
    // 平移不改变宽高，所以比例天然守恒
    sel = {
      x: clamp(base.x + dx, 0, Math.max(0, crop.dispW - base.w)),
      y: clamp(base.y + dy, 0, Math.max(0, crop.dispH - base.h)),
      w: base.w,
      h: base.h,
    };
  } else if (drag.mode === "new") {
    if (ratio) {
      const dirX = point.x >= drag.ox ? 1 : -1;
      const dirY = point.y >= drag.oy ? 1 : -1;
      // 斜着拖时取"斜边在两个方向上各自能撑出的最大宽度"，手感最接近自由拉框
      const wantW = Math.max(Math.abs(point.x - drag.ox), Math.abs(point.y - drag.oy) * ratio);
      sel = fitInside(boxFromAnchor(drag.ox, drag.oy, dirX, dirY,
        Math.max(CROP_MIN_PX, wantW), ratio));
    } else {
      const x2 = clamp(point.x, 0, crop.dispW);
      const y2 = clamp(point.y, 0, crop.dispH);
      const w = Math.max(Math.abs(x2 - drag.ox), CROP_MIN_PX);
      const h = Math.max(Math.abs(y2 - drag.oy), CROP_MIN_PX);
      sel = {
        x: clamp(Math.min(drag.ox, x2), 0, Math.max(0, crop.dispW - w)),
        y: clamp(Math.min(drag.oy, y2), 0, Math.max(0, crop.dispH - h)),
        w,
        h,
      };
    }
  } else if (ratio) {
    sel = fitInside(ratioFromHandle(drag.mode, base, point, ratio));
  } else {
    let left = base.x;
    let top = base.y;
    let right = base.x + base.w;
    let bottom = base.y + base.h;
    if (drag.mode.indexOf("w") >= 0) left = clamp(base.x + dx, 0, right - CROP_MIN_PX);
    if (drag.mode.indexOf("e") >= 0) right = clamp(right + dx, left + CROP_MIN_PX, crop.dispW);
    if (drag.mode.indexOf("n") >= 0) top = clamp(base.y + dy, 0, bottom - CROP_MIN_PX);
    if (drag.mode.indexOf("s") >= 0) bottom = clamp(bottom + dy, top + CROP_MIN_PX, crop.dispH);
    sel = { x: left, y: top, w: right - left, h: bottom - top };
  }

  crop.sel = sel;
  drawCrop();
  updateCropInfo();
  scheduleCropPreview();     // 预览用 rAF 节流，pointermove 再密也只画一帧
}

function onCropUp(event) {
  if (!crop.drag) return;
  crop.drag = null;
  try { el.cropCanvas.releasePointerCapture(event.pointerId); } catch (e) { /* 已释放 */ }
  drawCrop();
  updateCropInfo();
  scheduleCropPreview();
}

/** 按当前选区把原图的对应区域画到离屏 canvas，得到"裁剪后的文件"的字节。 */
function exportSelection() {
  const img = crop.img;
  const s = crop.sel;
  const scale = crop.scale;

  let sx = clamp(Math.round(s.x / scale), 0, Math.max(0, img.naturalWidth - 1));
  let sy = clamp(Math.round(s.y / scale), 0, Math.max(0, img.naturalHeight - 1));
  let iw = Math.min(Math.max(1, Math.round(s.w / scale)), img.naturalWidth - sx);
  let ih = Math.min(Math.max(1, Math.round(s.h / scale)), img.naturalHeight - sy);

  let ow = iw;
  let oh = ih;
  if (ow > CROP_MAX_W) {
    oh = Math.max(1, Math.round((ih * CROP_MAX_W) / iw));
    ow = CROP_MAX_W;
  }

  const out = document.createElement("canvas");
  out.width = ow;
  out.height = oh;
  const ctx = out.getContext("2d");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, sx, sy, iw, ih, 0, 0, ow, oh);

  return new Promise((resolve, reject) => {
    out.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error("图片编码失败"));
    }, "image/png");
  });
}

async function applyCrop() {
  if (!crop.img || crop.busy) return;
  crop.busy = true;
  el.cropOk.disabled = true;
  el.cropCancel.disabled = true;
  el.cropInfo.textContent = "正在裁剪并保存…";
  try {
    const blob = await exportSelection();
    await uploadAndApply(blob, `wallpaper-${stamp()}.png`);
    closeCrop();
    toast("已裁剪并设为壁纸", "ok");
  } catch (e) {
    el.cropInfo.textContent = `保存失败：${e.message}`;
  } finally {
    crop.busy = false;
    el.cropOk.disabled = false;
    el.cropCancel.disabled = false;
  }
}

function closeCrop() {
  el.crop.hidden = true;
  lockScroll(false);
  // 先撤掉待办的预览帧：图都释放了还画一帧，只会在关窗瞬间闪一下旧图
  if (crop.previewRaf) {
    try { cancelAnimationFrame(crop.previewRaf); } catch (e) { /* 老内核没有，忽略 */ }
    crop.previewRaf = 0;
  }
  crop.img = null;
  crop.drag = null;
  crop.busy = false;
  crop.sel = { x: 0, y: 0, w: 0, h: 0 };
  crop.scale = 1;
  // 置空尺寸：把上一张图占的位图内存还给浏览器
  const ctx = el.cropCanvas.getContext("2d");
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, el.cropCanvas.width, el.cropCanvas.height);
  el.cropCanvas.width = 1;
  el.cropCanvas.height = 1;
  el.cropCanvas.style.width = "1px";
  el.cropCanvas.style.height = "1px";
  if (el.cropPreview) {
    const pctx = el.cropPreview.getContext("2d");
    if (pctx) {
      pctx.setTransform(1, 0, 0, 1, 0, 0);
      pctx.clearRect(0, 0, el.cropPreview.width, el.cropPreview.height);
    }
    el.cropPreview.width = CROP_PREVIEW_W;
    el.cropPreview.height = CROP_PREVIEW_MIN_H;
  }
  el.cropInfo.textContent = "";
  el.cropOk.disabled = false;
  el.cropCancel.disabled = false;
}

function lockScroll(locked) {
  document.documentElement.classList.toggle("bg-lock", locked);
  document.body.classList.toggle("bg-lock", locked);
}

/* ---------------- 启动 ---------------- */

function bind() {
  el.pickImage.addEventListener("click", () => {
    el.fileImage.value = "";
    el.fileImage.click();
  });
  el.pickVideo.addEventListener("click", () => {
    el.fileVideo.value = "";
    el.fileVideo.click();
  });
  el.fileImage.addEventListener("change", onPickImage);
  el.fileVideo.addEventListener("change", onPickVideo);
  el.clear.addEventListener("click", clearWallpaper);

  el.mask.addEventListener("input", () => {
    el.maskVal.textContent = `${el.mask.value}%`;
  });
  el.mask.addEventListener("change", async () => {
    try {
      const state = await own("POST", "apply", { mask: Number(el.mask.value) });
      if (state) {
        current = normalise(state);
        paintNow(current);
        setStatus(current);
      }
      notifyShell();
    } catch (e) {
      toast(`遮罩保存失败：${e.message}`, "error");
    }
  });

  el.fit.addEventListener("change", async () => {
    try {
      const state = await own("POST", "apply", { fit: el.fit.value });
      if (state) {
        current = normalise(state);
        paintNow(current);
        setStatus(current);
      }
      notifyShell();
    } catch (e) {
      toast(`铺满方式保存失败：${e.message}`, "error");
    }
  });

  el.library.addEventListener("click", (event) => {
    const target = event.target instanceof Element ? event.target.closest("[data-act]") : null;
    if (!target) return;
    const url = target.dataset.url || "";
    if (target.dataset.act === "apply") applyMedia(url);
    else if (target.dataset.act === "del") armDelete({ url, name: target.dataset.name || url });
  });

  // 裁剪弹窗：取消 / 应用 / 右上角 / 点遮罩空白处 / Esc
  el.cropOk.addEventListener("click", applyCrop);
  el.cropCancel.addEventListener("click", closeCrop);
  el.cropX.addEventListener("click", closeCrop);
  if (el.cropRatios) {
    // 事件委托：按钮是静态写在 page.html 里的，但这样以后加比例也不用再绑一次
    el.cropRatios.addEventListener("click", (event) => {
      const btn = event.target instanceof Element ? event.target.closest("[data-ratio]") : null;
      if (!btn) return;
      setCropRatio(btn.dataset.ratio);
    });
  }
  el.crop.addEventListener("pointerdown", (event) => {
    if (event.target === el.crop) closeCrop();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape" || el.crop.hidden) return;
    event.preventDefault();
    event.stopPropagation();
    closeCrop();
  }, true);

  el.cropCanvas.addEventListener("pointerdown", onCropDown);
  el.cropCanvas.addEventListener("pointermove", onCropMove);
  el.cropCanvas.addEventListener("pointerup", onCropUp);
  el.cropCanvas.addEventListener("pointercancel", onCropUp);
}

async function boot() {
  // token 为空时所有请求都会 401，界面只会永远停在「读取中…」。与其静默空转，
  // 不如把原因直接写在状态行上 —— 这条路径通常是用户直接打开了页面文件、或弹窗丢了参数。
  if (!TOKEN) {
    if (el.status) {
      el.status.classList.add("warn");
      el.status.textContent =
        "未拿到访问令牌，请从「设置 → 外观 → 背景图片」重新打开";
    }
    if (el.nowName) el.nowName.textContent = "无法读取壁纸状态";
    if (el.nowHint) el.nowHint.textContent = "缺少访问令牌（t=）";
    setBusy(true, "缺少访问令牌，无法上传");   // 按钮留着能点只会让人以为程序坏了
    if (el.presets) {
      el.presets.innerHTML = "";
      mutedLine(el.presets, "缺少访问令牌，内置壁纸无法读取");
    }
    if (el.library) {
      el.library.innerHTML = "";
      mutedLine(el.library, "缺少访问令牌，已保存壁纸无法读取");
    }
    return;
  }
  bind();
  syncTheme();
  watchTheme();
  await loadPresets();
  const stateReady = await loadState();
  await refreshLibrary();
  // 状态读不到时也要把"当前壁纸"卡片画成默认值，
  // 但不能走 render()——那会用默认文案盖掉上面刚写好的失败原因。
  if (!stateReady) {
    paintNow(current);
    paintControls(current);
  }
}

boot();
