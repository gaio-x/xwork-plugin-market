/* 壁纸插件页面脚本。
 *
 * 两条调用通道，按可用性自动选：
 *   1. `window.xwork.api()`（主壳注入的受限桥，只放行本插件自己的 /x/ 前缀）——优先；
 *   2. 直接 fetch + URL 上的 `?t=` token —— 兜底。iframe 的 load 事件晚于本脚本执行，
 *      所以脚本跑起来时 `window.xwork` 往往还没注入，必须两条都支持。
 *
 * 原生文件选择框复用主程序已有的 `/api/fs/pick-file`（阻塞式对话框 + 轮询 result），
 * 不在插件里另造一套选择器。
 */

const PID = "xwork.bg-image";
const TOKEN = new URLSearchParams(location.search).get("t") || "";
const OWN = `/api/plugins/${PID}/x/`;
const POLL_MS = 350;
const PICK_TIMEOUT_MS = 180000;

const el = {
  presets: document.getElementById("presets"),
  path: document.getElementById("path"),
  pathHint: document.getElementById("path-hint"),
  pick: document.getElementById("pick"),
  applyPath: document.getElementById("apply-path"),
  mask: document.getElementById("mask"),
  maskVal: document.getElementById("mask-val"),
  clear: document.getElementById("clear"),
  status: document.getElementById("status"),
  maxSize: document.getElementById("max-size"),
};

/* ---------------- 传输 ---------------- */
async function request(url, method = "GET", body) {
  const res = await fetch(url, {
    method,
    headers: { "X-WB-Token": TOKEN, "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.detail || json.error || `HTTP ${res.status}`);
  return json.data;
}

/** 调本插件自己的接口（/api/plugins/xwork.bg-image/x/...） */
function own(method, path, body) {
  if (window.xwork && typeof window.xwork.api === "function") {
    return window.xwork.api(method, OWN + path, body).then((r) => r && r.data);
  }
  return request(OWN + path, method, body);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** 让主壳立刻重画壁纸（轮询只是兜底，正常路径靠这个事件）。 */
function notifyShell() {
  try {
    window.parent.dispatchEvent(new CustomEvent("xwork:bg-refresh"));
  } catch { /* 不在 iframe 里或被沙箱挡住：轮询会在 3 秒内追上 */ }
}

/* ---------------- 渲染 ---------------- */
let presets = [];

function setStatus(text, kind = "") {
  el.status.textContent = text;
  el.status.className = `status ${kind}`.trim();
}

function paintTiles(state) {
  el.presets.innerHTML = "";
  for (const p of presets) {
    const tile = document.createElement("button");
    tile.type = "button";
    tile.className = "tile";
    tile.dataset.id = p.id;
    tile.style.background = p.css;
    tile.title = p.name;
    const active = state && state.mode === "preset" && state.preset === p.id;
    tile.setAttribute("aria-pressed", active ? "true" : "false");
    if (active) tile.classList.add("on");
    tile.innerHTML = `<span class="tile-name">${escapeHtml(p.name)}</span>`;
    tile.addEventListener("click", () => applyPreset(p.id, p.name));
    el.presets.appendChild(tile);
  }
}

function render(state) {
  el.mask.value = String(state.mask);
  el.maskVal.textContent = `${state.mask}%`;
  if (state.image_path) el.path.value = state.image_path;
  paintTiles(state);

  if (state.error) {
    setStatus(state.error, "warn");
    return;
  }
  if (state.mode === "preset") setStatus(`当前：内置壁纸「${state.preset_name}」 · 遮罩 ${state.mask}%`, "ok");
  else if (state.mode === "custom") setStatus(`当前：本地图片 ${state.image_name} · 遮罩 ${state.mask}%`, "ok");
  else setStatus(`当前：无背景（纯色） · 遮罩 ${state.mask}%`, "");
}

function escapeHtml(text) {
  return String(text ?? "").replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ---------------- 动作 ---------------- */
async function save(body, okText) {
  try {
    const state = await own("POST", "apply", body);
    render(state);
    notifyShell();
    if (okText) el.pathHint.textContent = okText;
    return state;
  } catch (e) {
    setStatus(`操作失败：${e.message}`, "wrong");
    return null;
  }
}

async function applyPreset(id, name) {
  el.pathHint.textContent = "";
  await save({ preset: id }, `已应用内置壁纸「${name}」`);
}

async function applyPath() {
  const path = el.path.value.trim();
  if (!path) { el.pathHint.textContent = "请先填图片的绝对路径，或点「浏览…」挑一张"; return; }
  const state = await save({ path });
  if (state) el.pathHint.textContent = "已应用本地图片（若图片很大会有短暂卡顿）";
}

/* ---------------- 原生文件选择框 ---------------- */
async function pickFile() {
  el.pathHint.textContent = "已在系统对话框里等你选图…";
  try {
    const pre = await request("/api/fs/pick-file/result");
    if (!pre || pre.status !== "pending") {
      await request("/api/fs/pick-file", "POST",
        { kind: "any", title: "选择背景图片（png / jpg / webp）" });
    }
    const started = Date.now();
    while (Date.now() - started < PICK_TIMEOUT_MS) {
      await sleep(POLL_MS);
      let got;
      try {
        got = await request("/api/fs/pick-file/result");
      } catch {
        continue;      // 单次轮询失败（服务重启/瞬时错误）不算结束
      }
      if (!got || got.status === "pending") continue;
      if (got.status === "ok") {
        const path = got.path || (got.paths && got.paths[0]) || "";
        if (!path) { el.pathHint.textContent = "没有拿到路径，请手动填写"; return; }
        el.path.value = path;
        await applyPath();
        return;
      }
      if (got.status === "cancelled") { el.pathHint.textContent = "已取消选择"; return; }
      el.pathHint.textContent = `选择失败：${got.error || "未知原因"}`;
      return;
    }
    el.pathHint.textContent = "选择超时，请重新点「浏览…」或手动填写路径";
  } catch (e) {
    el.pathHint.textContent = `打不开文件选择框（${e.message}），请手动填写绝对路径`;
  }
}

/* ---------------- 启动 ---------------- */
async function boot() {
  el.pick.addEventListener("click", pickFile);
  el.applyPath.addEventListener("click", applyPath);
  el.clear.addEventListener("click", async () => {
    const state = await save({ clear: true });
    if (state) el.pathHint.textContent = "已恢复默认背景";
  });
  el.mask.addEventListener("input", () => {
    el.maskVal.textContent = `${el.mask.value}%`;
  });
  el.mask.addEventListener("change", () => {
    save({ mask: Number(el.mask.value) });
  });

  try {
    const info = await own("GET", "presets");
    presets = (info && info.items) || [];
    if (el.maxSize) el.maxSize.textContent = `${(info && info.max_image_kb) || 2048}KB`;
    const state = await own("GET", "state");
    render(state || { mode: "none", mask: 30, preset: "", image_path: "" });
  } catch (e) {
    el.presets.innerHTML = `<div class="empty">内置壁纸读取失败：${escapeHtml(e.message)}</div>`;
    setStatus("插件接口不可用：确认插件已启用并已授权", "wrong");
  }
}

boot();
