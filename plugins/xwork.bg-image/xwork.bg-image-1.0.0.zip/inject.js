/* 壁纸插件 · 全局脚本（contributes.injects / type=js）
 *
 * 运行位置：主界面主文档，与主程序**同上下文**（所以本插件要 ui.inject_global 高危权限）。
 *
 * 这一版把壁纸从"画在 body 的 background-image 上"改成**独立的固定背景层**：
 *
 *   <div id="xwork-bg-layer">      position:fixed; inset:0; z-index:-1
 *     <div id="xwork-bg-media">    图片 / 内置渐变（background-image）
 *     <video id="xwork-bg-video">  视频（object-fit 铺满）
 *   </div>
 *
 * 为什么必须换（这是"内置壁纸不显示"的根因）：web/style.css 里 `html, body` 都带
 * `background: var(--bg)` 实色，而 z-index:-1 的图层永远画在"会画背景的祖先"之下 ——
 * body 那层实色会把壁纸整块盖住。而且 body 只有一组 background-image，塞了图片就
 * 没地方放视频。所以背景层独立成节点，body 只在壁纸生效期间让出 background-color
 * （见 inject.css 末尾），关掉壁纸立刻恢复。
 *
 * 只做四件事：建/复用背景层、拉 /state、按 mode 画、轮询兜底。
 * 不改别人的 DOM、不绑别人的事件、不引任何外部依赖（本文件会被原文灌进主文档）。
 */
(function () {
  "use strict";

  if (window.__XWORK_BG_READY__) return;      // 重复注入就跳过：别建两个容器、别装两套定时器
  window.__XWORK_BG_READY__ = true;

  var pid = (typeof __WB_PLUGIN__ === "object" && __WB_PLUGIN__ && __WB_PLUGIN__.id)
    ? __WB_PLUGIN__.id : "xwork.bg-image";
  var BASE = "/api/plugins/" + pid + "/x/";
  var POLL_MS = 3000;
  /** 连错几次就认定"插件已停用/卸载或拿不到 token"，彻底撤掉背景层并停机。 */
  var MAX_FAILS = 3;

  var LAYER_ID = "xwork-bg-layer";
  var MEDIA_ID = "xwork-bg-media";
  var VIDEO_ID = "xwork-bg-video";

  var layer = null;
  var mediaEl = null;
  var videoEl = null;

  var lastRev = "";          // 上一次真正画上去的状态指纹
  var lastVideoSrc = "";     // 上一次设给 <video> 的完整地址（含 ?t=），相同就不再赋一次
  var mode = "";             // 当前模式：none / preset / image / video
  var painted = false;       // 是否成功画过一次（容器被外力删掉时能自愈）
  var busy = false;
  var fails = 0;
  var timer = 0;
  var dead = false;

  /* ---------------- 取 token / 取状态 ---------------- */

  /** 主界面走 window.__WB_TOKEN__；URL 上的 ?t= 只是兜底（iframe、手工打开页面时用得到）。 */
  function token() {
    if (window.__WB_TOKEN__) return String(window.__WB_TOKEN__);
    try {
      var m = /[?&]t=([^&#]+)/.exec(String((window.location && window.location.search) || ""));
      if (m) return decodeURIComponent(m[1]);
    } catch (e) { /* 解码失败就当没有 token，按失败计数走 */ }
    return "";
  }

  function get(path) {
    var headers = {};
    var tok = token();
    if (tok) headers["X-WB-Token"] = tok;
    if (typeof window.fetch !== "function") return Promise.reject(new Error("no fetch"));
    return window.fetch(BASE + path, { headers: headers, cache: "no-store" })
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .then(function (json) { return (json && json.data) || null; });
  }

  /* ---------------- 背景层节点 ---------------- */

  /** 幂等建层：已有就复用（连子节点被清掉这种半残状态也补齐），没有就建。 */
  function ensureLayer() {
    if (layer && layer.parentNode) return layer;
    if (!document.body) return null;           // 脚本跑得太早：下次轮询再建
    layer = document.getElementById(LAYER_ID);
    if (!layer) {
      layer = document.createElement("div");
      layer.id = LAYER_ID;
      layer.setAttribute("aria-hidden", "true");
      document.body.appendChild(layer);
    }
    mediaEl = document.getElementById(MEDIA_ID);
    if (!mediaEl) {
      mediaEl = document.createElement("div");
      mediaEl.id = MEDIA_ID;
      layer.appendChild(mediaEl);
    }
    videoEl = document.getElementById(VIDEO_ID);
    if (!videoEl) {
      videoEl = document.createElement("video");
      videoEl.id = VIDEO_ID;
      // muted 用两条都设：标签属性是浏览器放行自动播放的前提，property 才是运行时开关
      videoEl.muted = true;
      videoEl.setAttribute("muted", "");
      videoEl.setAttribute("loop", "");
      videoEl.setAttribute("playsinline", "");
      videoEl.setAttribute("autoplay", "");
      videoEl.setAttribute("preload", "auto");
      layer.appendChild(videoEl);
    }
    return layer;
  }

  /* ---------------- 画 ---------------- */

  /** 遮罩浓度：后端给 0~80 的整数，这里换成 rgba 写进 CSS 变量（深浅主题各一份）。 */
  function setMask(mask) {
    var alpha = Math.max(0, Math.min(80, Number(mask) || 0)) / 100;
    var style = document.documentElement.style;
    style.setProperty("--bg-mask-light", "rgba(255,255,255," + alpha + ")");
    style.setProperty("--bg-mask-dark", "rgba(9,13,18," + alpha + ")");
  }

  function setFlag(on) {
    if (on) document.documentElement.setAttribute("data-bg-image", "on");
    else document.documentElement.removeAttribute("data-bg-image");
  }

  /** 停掉视频并断开解码：隐藏后还在后台下载是最没必要的开销。 */
  function stopVideo() {
    if (!videoEl) return;
    try { videoEl.pause(); } catch (e) { /* 没加载过时 pause 可能抛，忽略 */ }
    if (lastVideoSrc) {
      lastVideoSrc = "";
      try { videoEl.removeAttribute("src"); } catch (e) { /* 属性不存在 */ }
      try { videoEl.load(); } catch (e) { /* 老内核不支持，忽略 */ }
    }
    videoEl.style.display = "none";
  }

  function play() {
    if (!videoEl) return;
    try {
      var p = videoEl.play();
      // 浏览器可能拦自动播放：吞掉异常，界面停在首帧，不弹窗不报错。
      if (p && typeof p.catch === "function") p.catch(function () { /* 被拦截，保持首帧 */ });
    } catch (e) { /* 老内核 play() 同步抛错，同样忽略 */ }
  }

  function imageFit(fit) {
    if (!mediaEl) return;
    if (fit === "contain") {
      mediaEl.style.backgroundSize = "contain";
      mediaEl.style.backgroundRepeat = "no-repeat";
      return;
    }
    if (fit === "repeat") {
      mediaEl.style.backgroundSize = "auto";
      mediaEl.style.backgroundRepeat = "repeat";
      return;
    }
    mediaEl.style.backgroundSize = "cover";
    mediaEl.style.backgroundRepeat = "no-repeat";
  }

  function playVideo(url, fit) {
    if (!videoEl) return;
    var tok = token();
    var src = url + (url.indexOf("?") >= 0 ? "&" : "?") + "t=" + encodeURIComponent(tok);
    if (!tok) src = url;                       // 没 token 就原样请求（会 401，由失败计数兜底）
    if (src !== lastVideoSrc) {
      lastVideoSrc = src;
      videoEl.src = src;                       // 只在地址变化时赋值，否则每轮都会从头播
      try { videoEl.load(); } catch (e) { /* 老内核不支持，忽略 */ }
    }
    videoEl.style.display = "block";
    // repeat 对视频没有意义（会露黑边），静默退化成 cover，也不刷警告。
    videoEl.style.objectFit = (fit === "contain") ? "contain" : "cover";
    play();
  }

  /** 画一屏。返回 false 表示节点还建不出来（body 未就绪），调用方不要把 rev 记下。 */
  function paint(st) {
    if (!ensureLayer()) return false;
    setMask(st.mask);

    if (st.mode === "preset" && st.preset_css) {
      stopVideo();
      mediaEl.style.display = "block";
      mediaEl.style.backgroundImage = st.preset_css;   // 纯 CSS 渐变，原样塞进去
      mediaEl.style.backgroundSize = "cover";
      mediaEl.style.backgroundRepeat = "no-repeat";
      mode = "preset";
    } else if (st.mode === "image" && st.media_url) {
      stopVideo();
      mediaEl.style.display = "block";
      mediaEl.style.backgroundImage = 'url("' + st.media_url + '")';
      imageFit(st.fit);
      mode = "image";
    } else if (st.mode === "video" && st.media_url) {
      mediaEl.style.display = "none";
      mediaEl.style.backgroundImage = "none";
      playVideo(st.media_url, st.fit);
      mode = "video";
    } else {
      stopVideo();                                     // none（含"文件已被删"降级）
      mediaEl.style.display = "block";
      mediaEl.style.backgroundImage = "none";
      mediaEl.style.backgroundSize = "cover";
      mediaEl.style.backgroundRepeat = "no-repeat";
      mode = "none";
    }
    setFlag(mode !== "none");
    return true;
  }

  /* ---------------- 撤场 ---------------- */

  /** 插件被停用/卸载、或一直拿不到 token：撤掉容器 + 清标记 + 停机，别留一张没人管的图。 */
  function teardown() {
    dead = true;
    if (timer) { clearInterval(timer); timer = 0; }
    var node = (layer && layer.parentNode) ? layer : document.getElementById(LAYER_ID);
    if (node && node.parentNode) node.parentNode.removeChild(node);
    layer = null;
    mediaEl = null;
    videoEl = null;
    lastRev = "";
    lastVideoSrc = "";
    painted = false;
    mode = "none";
    setFlag(false);
    try {
      var style = document.documentElement.style;
      style.removeProperty("--bg-mask-light");
      style.removeProperty("--bg-mask-dark");
    } catch (e) { /* 老内核没有 removeProperty，留个空变量也无害 */ }
  }

  function fail() {
    fails += 1;
    if (fails >= MAX_FAILS) teardown();
  }

  /* ---------------- 刷新 ---------------- */

  function refresh() {
    if (dead || busy) return;
    busy = true;
    get("state").then(function (st) {
      busy = false;
      if (dead) return;
      if (!st) { fail(); return; }                     // 接口通了但没 data：算一次失败
      fails = 0;
      // rev 没变就完全跳过重绘 —— 视频正在播时重设 src 会从头开始，这是最容易被忽略的坑。
      if (st.rev === lastRev && painted && layer && layer.parentNode) {
        if (mode === "video" && videoEl && videoEl.paused) play();   // 只救"被暂停"，不碰 src
        return;
      }
      lastRev = paint(st) ? st.rev : "";               // 画不成就别记指纹，下一轮再试
      painted = !!lastRev;
    }).catch(function () {
      busy = false;
      if (!dead) fail();
    });
  }

  /* 三条"立刻刷新"通道：插件页/设置页动作后的事件、iframe 的 postMessage 兜底、回到前台。 */
  window.addEventListener("xwork:bg-refresh", function () { refresh(); });
  window.addEventListener("message", function (ev) {
    var d = ev && ev.data;
    if (d && typeof d === "object" && d.type === "xwork:bg-refresh") refresh();
  });
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) refresh();
  });

  refresh();
  timer = setInterval(refresh, POLL_MS);
})();
