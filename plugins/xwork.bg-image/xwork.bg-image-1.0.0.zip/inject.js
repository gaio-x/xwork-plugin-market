/* 壁纸插件 · 全局脚本（contributes.injects / type=js）
 *
 * 运行位置：主界面主文档，与主程序**同上下文**（所以本插件要 ui.inject_global 高危权限）。
 * 它只做一件窄事：把自己的状态接口读出来，写进 <html> 上的两个 CSS 变量，
 * 由 inject.css 负责画到 body 上。不改 DOM 结构、不绑事件到别人的按钮上。
 *
 * 为什么是轮询而不是"推送"：插件页在自己的 iframe 里，主壳没有给插件开"向主壳推消息"
 * 的正式通道（xwork.* 是主壳→插件页方向）。所以这里 3 秒拉一次很小的 /state，
 * 并在插件页/设置页动作后派发 xwork:bg-refresh 事件让它立刻刷新 —— 效果就是
 * "点一下缩略图，界面背景马上变"，不用重启。
 */
(function () {
  "use strict";

  if (window.__XWORK_BG_READY__) return;      // 重复注入就跳过，别装两套定时器
  window.__XWORK_BG_READY__ = true;

  var pid = (typeof __WB_PLUGIN__ === "object" && __WB_PLUGIN__ && __WB_PLUGIN__.id)
    ? __WB_PLUGIN__.id : "xwork.bg-image";
  var BASE = "/api/plugins/" + pid + "/x/";
  var POLL_MS = 3000;

  var lastRev = "";
  var rawRev = "";
  var rawUrl = "";
  var busy = false;
  var fails = 0;

  function get(path) {
    var headers = {};
    if (window.__WB_TOKEN__) headers["X-WB-Token"] = window.__WB_TOKEN__;
    return fetch(BASE + path, { headers: headers, cache: "no-store" })
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .then(function (json) { return (json && json.data) || null; });
  }

  function paint(image, mask) {
    var root = document.documentElement;
    var alpha = Math.max(0, Math.min(80, Number(mask) || 0)) / 100;
    root.style.setProperty("--bg-image", image || "none");
    root.style.setProperty("--bg-mask-light", "rgba(255,255,255," + alpha + ")");
    root.style.setProperty("--bg-mask-dark", "rgba(9,13,18," + alpha + ")");
    if (image) root.setAttribute("data-bg-image", "on");
    else root.removeAttribute("data-bg-image");
  }

  function applyState(st) {
    var mask = st.mask;
    if (st.mode === "preset" && st.preset_css) {
      paint(st.preset_css, mask);
      return;
    }
    if (st.mode !== "custom") {
      paint("", mask);
      return;
    }
    if (rawUrl && rawRev === st.rev) {
      paint('url("' + rawUrl + '")', mask);
      return;
    }
    // 先按"无图"画一次避免停在旧图上，再取字节（2MB 图的 base64 约 2.7MB，只取一次）。
    paint("", mask);
    get("raw").then(function (raw) {
      if (!raw || raw.error || !raw.data_url) return;
      rawRev = st.rev;
      rawUrl = raw.data_url;
      paint('url("' + rawUrl + '")', mask);
    }).catch(function () { /* 拿不到就保持无背景，页面上会显示原因 */ });
  }

  function refresh(force) {
    if (busy) return;
    busy = true;
    get("state").then(function (st) {
      busy = false;
      if (!st) {
        // 插件被停用/卸载后接口会 404/400：连错 3 次就把背景撤掉，别留一张没人管的图。
        fails += 1;
        if (fails >= 3) paint("", 0);
        return;
      }
      fails = 0;
      if (!force && st.rev === lastRev) return;
      lastRev = st.rev;
      applyState(st);
    }).catch(function () {
      busy = false;
      fails += 1;
      if (fails >= 3) paint("", 0);
    });
  }

  // 插件页/设置页改完设置后派发这个事件，主界面立刻重画（轮询只是兜底）。
  window.addEventListener("xwork:bg-refresh", function () { refresh(true); });
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) refresh(false);
  });

  refresh(true);
  setInterval(function () { refresh(false); }, POLL_MS);
})();
