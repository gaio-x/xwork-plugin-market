"""壁纸插件后端：记录「当前用哪张壁纸 + 遮罩多浓 + 怎么铺」，供主界面注入脚本取用。

五件事：
1. 内置 8 套渐变壁纸（纯 CSS 渐变，不联网、不引用外网图片）；
2. 记录用户选的壁纸（内置 / 图片 / 视频）、遮罩浓度与铺满方式 —— 存在插件的自配置里
   （data/plugin-state.json），**不写主程序的 settings.json**，也不碰别的插件的键；
3. `GET /state` 给注入脚本轮询（很小的 JSON），`GET /presets` / `GET /library` 给设置界面
   画缩略图与已保存列表；
4. `POST /apply` / `POST /remove` 是仅有的两个写入口；
5. 命令 `bg.apply` / `bg.clear` / `bg.status` / `bg.list`。

## 三条必须交代的边界（都是宿主契约限制，不是实现偷懒）

**A. 图片/视频为什么不再走 base64、也不限大小**
宿主的插件自有路由 `/api/plugins/<id>/x/...` 返回值统一包成 `{"ok":true,"data":...}` 且限 4MB，
根本装不下视频。所以 v1.0.0 起改用主程序的**插件媒体存储**路由，原始字节收发、支持 Range：

    POST   /api/plugins/xwork.bg-image/media?name=<文件名>   body=原始字节 → {"name","url","bytes","kind"}
    GET    /api/plugins/xwork.bg-image/media/<文件名>        → 原始字节（<img>/<video> 可直接用）
    DELETE /api/plugins/xwork.bg-image/media/<文件名>        → 删除；?all=1 清空

落地位置由主程序决定（`DATA_DIR/plugins/xwork.bg-image/media/`）。插件这边**不写盘**，
也不再需要 `fs.read`（浏览器选的文件由前端直接上传，不再从用户磁盘读路径后编码）——
权限因此从 `["ui.inject_global","fs.read"]` 收敛为 `["ui.inject_global","fs.write"]`
（媒体路由的写/删要求 fs.write）。

**B. 删除落地文件只能由前端做（方案 b）**
`PluginAPI` 实测只有 `read_text/read_bytes/list_dir/file_info/create_file/rename/
http_get_json` 这几样：没有删除文件的方法，`http_get_json` 又只支持 GET 且明确拒绝
localhost/127.0.0.1（防 SSRF 打内网），插件进程内发不出那条 `DELETE /api/plugins/.../media/<name>`。
所以 `POST /remove` 只做两件事：更新插件状态、把要删的文件连同**完整删除地址**回给前端，
由持有 token 的前端去调主程序那条 DELETE（前端天然能发）。返回体里 `deleted` 恒为 false，
`reason` 写清"为什么不是后端删的"，`files[].delete_url` 是前端可直接 fetch 的地址。

**C. 已保存壁纸清单靠插件状态维护，不是磁盘扫描**
同样因为没有 `fs.read`：媒体目录在 `DATA_DIR` 下，既不在工作区挂载白名单里，也没有列目录的
权限。而为了"列个目录"再申请 `fs.read` 明显违背权限最小化（这个插件已经完全不需要读用户
磁盘了）。所以清单存在插件自配置 `wallpaper` 这个键里（JSON：当前内置壁纸 / 当前媒体地址 /
已保存条目），上传时追加、删除时移除 —— 插件自己就是这份清单的唯一事实来源。
代价：用户在资源管理器里手删了媒体文件，清单不会自动少一行；所以 `GET /state` 会把
"当前媒体不在清单里"当作"文件已被删"处理（降级成 none 并给一句中文原因）。
"""
from __future__ import annotations

import hashlib
import json
import re
import time

PLUGIN_ID = "xwork.bg-image"
# 主程序媒体存储路由的前缀。GET 出来的地址可以直接塞进 <img>/<video>/background-image。
MEDIA_BASE = f"/api/plugins/{PLUGIN_ID}/media/"

# 内置壁纸：id / 名称 / CSS 值。纯渐变，不依赖任何外部资源，深色浅色都不刺眼。
PRESETS = [
    {"id": "morning", "name": "晨雾",
     "css": "linear-gradient(135deg,#e9eff7 0%,#d2dfee 45%,#bacde1 100%)"},
    {"id": "deep-sea", "name": "深海",
     "css": "linear-gradient(160deg,#0f2233 0%,#16324a 50%,#1d4a63 100%)"},
    {"id": "graphite", "name": "石墨",
     "css": "linear-gradient(135deg,#24272c 0%,#343940 55%,#1b1e22 100%)"},
    {"id": "bamboo", "name": "竹青",
     "css": "linear-gradient(140deg,#e7efe5 0%,#c8dcc7 50%,#a4c4a6 100%)"},
    {"id": "dusk", "name": "暮色",
     "css": "linear-gradient(150deg,#2a2140 0%,#4a2f56 45%,#8a4a55 100%)"},
    {"id": "paper", "name": "宣纸",
     "css": "linear-gradient(135deg,#f7f3ea 0%,#efe6d6 60%,#e3d6bf 100%)"},
    {"id": "aurora", "name": "极光",
     "css": "linear-gradient(135deg,#0b1a2a 0%,#12454c 45%,#2f7d6b 100%)"},
    {"id": "sakura", "name": "樱粉",
     "css": "linear-gradient(135deg,#f8e9ef 0%,#efd2de 55%,#e0b9cb 100%)"},
]

IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".avif", ".svg")
VIDEO_SUFFIXES = (".mp4", ".webm", ".ogv", ".ogg", ".m4v", ".mov")

DEFAULT_MASK = 30
MASK_MIN, MASK_MAX = 0, 80

DEFAULT_FIT = "cover"
# 顺序即设置界面的展示顺序；label 是给用户看的中文，value 才是写进状态的值。
FIT_OPTIONS = [
    {"value": "cover", "label": "铺满（裁掉多余部分）"},
    {"value": "contain", "label": "完整显示（可能留边）"},
    {"value": "repeat", "label": "平铺"},
]
FIT_VALUES = tuple(item["value"] for item in FIT_OPTIONS)

# 主程序媒体路由的单文件上限（提示用）。取消的是"插件侧 2MB/base64 4MB"的老限制，
# 主程序仍有一个物理上限（防一次塞进几个 G 把内存吃穿），这里只把数字透给前端做校验提示。
MAX_UPLOAD_MB = 512

# 主程序只接受 [A-Za-z0-9._-] 的文件名，且不支持子目录 —— 与它保持一致，提前挡掉。
MEDIA_NAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,120}$")

# 状态一律塞在这一个自配置键里（见文件头说明 C）。
STATE_KEY = "wallpaper"


def _find_preset(preset_id: str) -> dict | None:
    for item in PRESETS:
        if item["id"] == preset_id:
            return item
    return None


def _clamp_mask(value) -> int:
    """遮罩浓度收敛到 0~80；脏值（空串/非法）回落到默认值而不是报错。"""
    try:
        num = int(round(float(value)))
    except (TypeError, ValueError):
        return DEFAULT_MASK
    return max(MASK_MIN, min(MASK_MAX, num))


def _norm_fit(value) -> str:
    """铺满方式只认三个值，其余（含空串/脏值）回落 cover。"""
    text = str(value or "").strip().lower()
    return text if text in FIT_VALUES else DEFAULT_FIT


def _kind_of(name: str) -> str:
    """按扩展名判 image / video / other —— 与主程序返回的 kind 口径一致。"""
    low = str(name or "").lower()
    if low.endswith(IMAGE_SUFFIXES):
        return "image"
    if low.endswith(VIDEO_SUFFIXES):
        return "video"
    return "other"


def _media_name(value: str) -> str:
    """把"完整 URL / 相对路径 / 纯文件名"统一取成合法文件名；不合法返回空串。"""
    text = str(value or "").strip().split("?", 1)[0].rstrip("/")
    tail = text.rsplit("/", 1)[-1]
    return tail if MEDIA_NAME_RE.match(tail) else ""


def _media_url(name: str) -> str:
    return MEDIA_BASE + name


def _rev(*parts) -> str:
    """状态指纹：注入脚本只在指纹变化时重画，避免每 3 秒重设一次大图/视频。"""
    text = "|".join(str(p) for p in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]


# ---------------------------------------------------------------- 状态读写
def _load_state(api) -> dict:
    """读插件状态。**任何脏数据都退回空状态**，绝不抛错（这个函数在每个接口的最前面）。"""
    raw = api.get_setting(STATE_KEY, "") or ""
    data: dict = {}
    if isinstance(raw, dict):
        data = dict(raw)
    elif isinstance(raw, str) and raw.strip():
        try:
            got = json.loads(raw)
        except (ValueError, TypeError):
            got = None
        if isinstance(got, dict):
            data = got
    preset = str(data.get("preset") or "").strip()
    media_url = str(data.get("media_url") or "").strip()
    library: list[dict] = []
    seen: set[str] = set()
    for item in data.get("library") or []:
        if not isinstance(item, dict):
            continue
        name = _media_name(item.get("name") or item.get("url") or "")
        if not name or name in seen:
            continue
        seen.add(name)
        try:
            size = max(0, int(item.get("bytes") or 0))
        except (TypeError, ValueError):
            size = 0
        try:
            added = float(item.get("added") or 0)
        except (TypeError, ValueError):
            added = 0.0
        library.append({"url": _media_url(name), "name": name,
                        "kind": _kind_of(name), "bytes": size, "added": added})
    library.sort(key=lambda e: e["added"], reverse=True)
    return {"preset": preset, "media_url": media_url, "library": library}


def _save_state(api, data: dict) -> None:
    api.set_setting(STATE_KEY, json.dumps(data, ensure_ascii=False))


def _entry(data: dict, key: str) -> dict | None:
    """按 URL 或文件名找已保存条目。"""
    name = _media_name(key)
    for item in data["library"]:
        if item["name"] == name or item["url"] == str(key).strip():
            return item
    return None


def _state(api) -> dict:
    """当前生效的壁纸状态。**永不抛错**：媒体文件没了就降级成"无背景"并带上原因。

    注入脚本每 3 秒调一次这个接口，抛错会变成日志洪水，也会让界面停在旧图上。
    """
    out = {
        "mode": "none",              # none / preset / image / video
        "preset": "", "preset_name": "", "preset_css": "",
        "media_url": "", "media_name": "", "media_kind": "",
        "mask": DEFAULT_MASK, "fit": DEFAULT_FIT,
        "rev": _rev("none", DEFAULT_MASK, DEFAULT_FIT),
        "error": "",
    }
    try:
        data = _load_state(api)
        mask = _clamp_mask(api.get_setting("mask", DEFAULT_MASK))
        fit = _norm_fit(api.get_setting("fit", DEFAULT_FIT))
    except Exception as exc:  # noqa: BLE001 自配置读坏了也不能让轮询接口 500
        out["error"] = f"壁纸状态读取失败：{type(exc).__name__}: {exc}"
        return out
    out["mask"], out["fit"] = mask, fit

    hit = _find_preset(data["preset"])
    if hit:
        out.update({"mode": "preset", "preset": hit["id"], "preset_name": hit["name"],
                    "preset_css": hit["css"],
                    "rev": _rev("preset", hit["id"], mask, fit)})
        return out
    if not data["media_url"]:
        out["rev"] = _rev("none", mask, fit)
        return out

    entry = _entry(data, data["media_url"])
    if not entry:
        # 清单里没有 = 落地文件已被删（插件侧唯一能看到的证据，见文件头说明 C）
        out.update({"rev": _rev("broken", data["media_url"], mask, fit),
                    "error": "壁纸文件已被删除或不在清单中，请重新选择一张"})
        return out
    kind = entry["kind"] if entry["kind"] in ("image", "video") else "other"
    out.update({"media_url": entry["url"], "media_name": entry["name"],
                "media_kind": kind,
                "rev": _rev(kind, entry["url"], mask, fit)})
    if kind == "other":
        # 认不出扩展名就不敢往 CSS 里塞：回 none 并说明原因，别让界面挂一张裂图。
        out["error"] = "该文件的格式无法作为壁纸显示（只支持图片或视频）"
        return out
    out["mode"] = kind
    return out


def _library(api) -> dict:
    """已保存壁纸列表。`active` 标出当前正在用的那一个（界面据此画选中态）。"""
    data = _load_state(api)
    active_name = _media_name(data["media_url"])
    items = [{"url": e["url"], "name": e["name"], "kind": e["kind"], "bytes": e["bytes"],
              "active": bool(active_name) and e["name"] == active_name}
             for e in data["library"]]
    return {"items": items}


# ---------------------------------------------------------------- 写入口
def _apply(api, *, preset=None, media_url=None, media_name="", media_bytes=0,
           mask=None, fit=None, clear=False) -> dict:
    """写状态。preset 与 media_url 互斥：谁后应用谁生效，另一个清空
    （避免"看着是 A 实际是 B"这种最难排查的状态）。

    切换壁纸**不删**上一张文件：用户随时可能想切回来，落地文件只在显式删除时清掉。
    """
    data = _load_state(api)
    if clear:
        data["preset"], data["media_url"] = "", ""
    if preset is not None:
        preset_id = str(preset or "").strip()
        if preset_id and not _find_preset(preset_id):
            raise ValueError(f"没有这套内置壁纸：{preset_id}")
        data["preset"] = preset_id
        if preset_id:
            data["media_url"] = ""
    if media_url is not None:
        raw_url = str(media_url or "").strip()
        if not raw_url:
            data["media_url"] = ""
        else:
            name = _media_name(raw_url) or _media_name(media_name)
            if not name:
                raise ValueError("媒体文件名不合法（只允许字母、数字、点、下划线、短横线）")
            kind = _kind_of(name)
            if kind == "other":
                # 认不出扩展名就不登记：否则清单里会攒一堆"点了没反应"的条目
                raise ValueError("不支持该文件格式，请选择图片（png/jpg/webp/gif…）或视频（mp4/webm…）")
            try:
                size = max(0, int(media_bytes or 0))
            except (TypeError, ValueError):
                size = 0
            entry = _entry(data, name)
            if entry:
                # 重复应用同一个文件（比如刚裁剪过、字节变了）：刷新元数据，保留排序时间
                entry.update({"url": _media_url(name), "kind": kind})
                if size:
                    entry["bytes"] = size
            else:
                data["library"].insert(0, {"url": _media_url(name), "name": name,
                                           "kind": kind, "bytes": size,
                                           "added": time.time()})
            data["media_url"] = _media_url(name)
            data["preset"] = ""
    if mask is not None:
        api.set_setting("mask", _clamp_mask(mask))
    if fit is not None:
        api.set_setting("fit", _norm_fit(fit))
    _save_state(api, data)
    return _state(api)


def _remove(api, *, url=None, all_items=False) -> dict:
    """从清单移除（不改开关、不删其它文件）。落地文件由前端按返回的 delete_url 删。

    为什么后端不删：见文件头说明 B —— 插件进程没有删文件的能力，也发不出那条 HTTP DELETE。
    """
    data = _load_state(api)
    current = _media_name(data["media_url"])
    removed: list[dict] = []
    if all_items:
        removed = list(data["library"])
        data["library"] = []
        data["media_url"] = ""
    else:
        target = str(url or "").strip()
        name = _media_name(target)
        if not name and not target:
            raise ValueError("请提供要删除的媒体地址（url）或 all: true")
        picked = _entry(data, name or target)
        if not picked:
            return {"deleted": False, "handled_by": "frontend",
                    "reason": "清单里没有这个文件（可能已经删过了）",
                    "files": [], "state": _state(api), "library": _library(api)}
        removed = [picked]
        data["library"] = [e for e in data["library"] if e["url"] != picked["url"]]
        if current and current == picked["name"]:
            data["media_url"] = ""      # 删的是当前壁纸 → 回到无背景
    _save_state(api, data)
    files = [{"name": e["name"], "url": e["url"], "delete_url": _media_url(e["name"]),
              "kind": e["kind"], "bytes": e["bytes"]} for e in removed]
    return {"deleted": False, "handled_by": "frontend",
            "reason": ("插件进程没有删除媒体文件的能力（无 fs 删除/无 HTTP 客户端），"
                       "已从清单移除；请由前端调用 files[].delete_url 删除落地文件"),
            "files": files, "state": _state(api), "library": _library(api)}


def register(api) -> None:
    @api.on_activate
    def _on_activate() -> None:
        st = _state(api)
        api.log(f"壁纸插件已激活（当前：{st['mode']}"
                f"{'/' + st['preset_name'] if st['preset_name'] else ''}"
                f"{'/' + st['media_name'] if st['media_name'] else ''}）")

    @api.on_deactivate
    def _on_deactivate() -> None:
        # 停用后注入的 CSS/JS 会随界面重载一起消失；状态留在自配置里，
        # 重新启用时背景原样回来（落地文件也还在，不会因为停用丢图）。
        api.log("壁纸插件已停用（界面重载后背景恢复默认，壁纸文件保留）")

    # ---------------- 自有接口 ----------------
    @api.route("state")
    def _route_state(ctx: dict) -> dict:
        """GET /api/plugins/xwork.bg-image/x/state —— 注入脚本每 3 秒轮询的就是它。"""
        return _state(api)

    @api.route("presets")
    def _route_presets(ctx: dict) -> dict:
        """GET .../x/presets —— 内置壁纸清单 + 可调范围（页面不写死任何一项）。"""
        return {"items": [{"id": p["id"], "name": p["name"], "css": p["css"]}
                          for p in PRESETS],
                "mask_range": [MASK_MIN, MASK_MAX],
                "fit_options": [dict(item) for item in FIT_OPTIONS],
                "max_upload_mb": MAX_UPLOAD_MB,
                # 给 <input type="file" accept> 用：图片与视频都要，不再限制大小
                "accept": ",".join(IMAGE_SUFFIXES + VIDEO_SUFFIXES)}

    @api.route("library")
    def _route_library(ctx: dict) -> dict:
        """GET .../x/library —— 已保存的壁纸（按加入时间倒序，active 标当前）."""
        return _library(api)

    @api.route("apply", methods=("POST",))
    def _route_apply(ctx: dict) -> dict:
        """POST .../x/apply —— {preset?} / {mediaUrl?, mediaName?, mediaBytes?} / {mask?} / {fit?} / {clear?}。

        语义：preset 与 mediaUrl 互斥，后写的生效并清掉另一个；标签/字节是上传接口回给
        前端的元数据，一并带上来就能把文件登记进"已保存壁纸"清单（清单靠状态维护，
        见文件头说明 C）。返回当前完整状态。
        """
        body = ctx.get("body") or {}
        return _apply(api,
                      preset=body.get("preset") if "preset" in body else None,
                      media_url=body.get("mediaUrl") if "mediaUrl" in body else None,
                      media_name=str(body.get("mediaName") or ""),
                      media_bytes=body.get("mediaBytes") or 0,
                      mask=body.get("mask") if "mask" in body else None,
                      fit=body.get("fit") if "fit" in body else None,
                      clear=bool(body.get("clear")))

    @api.route("remove", methods=("POST",))
    def _route_remove(ctx: dict) -> dict:
        """POST .../x/remove —— {"url": "..."} 删一个 / {"all": true} 清空。

        返回体里给出 files[].delete_url：插件只改状态，落地文件由前端删（见文件头说明 B）。
        """
        body = ctx.get("body") or {}
        return _remove(api, url=body.get("url") or "", all_items=bool(body.get("all")))

    # ---------------- 命令 ----------------
    @api.command("bg.apply", "壁纸：换一张", group="插件",
                 description="应用内置壁纸（preset）或媒体地址（mediaUrl），可选同时改遮罩（mask）与铺满方式（fit）",
                 args={"preset": "?str", "mediaUrl": "?str", "mask": "?str", "fit": "?str"},
                 keywords="壁纸 背景 背景图 换图 视频")
    def apply(preset: str = "", mediaUrl: str = "", mask: str = "",
              fit: str = "") -> dict:
        if not preset and not mediaUrl and mask == "" and fit == "":
            raise ValueError("请提供内置壁纸 id（preset）、媒体地址（mediaUrl），"
                             "或遮罩（mask）/铺满方式（fit）之一")
        return {"data": _apply(api,
                               preset=preset if preset else None,
                               media_url=mediaUrl if mediaUrl else None,
                               mask=mask if mask != "" else None,
                               fit=fit if fit != "" else None)}

    @api.command("bg.clear", "壁纸：恢复默认背景", group="插件",
                 description="清掉壁纸（内置与图片/视频），界面回到纯色背景；遮罩与铺满方式保留，已保存的文件不删",
                 keywords="壁纸 恢复 默认 清除 背景")
    def clear() -> dict:
        return {"data": _apply(api, clear=True)}

    @api.command("bg.status", "壁纸：当前状态", group="插件", silent=True,
                 description="返回当前壁纸模式、名称、遮罩浓度与铺满方式",
                 keywords="壁纸 状态 当前")
    def status() -> dict:
        return {"data": _state(api)}

    @api.command("bg.list", "壁纸：已保存的壁纸", group="插件", silent=True,
                 description="列出已保存的壁纸文件（图片/视频），active 标出当前正在用的那个",
                 keywords="壁纸 列表 已保存 图片 视频")
    def list_saved() -> dict:
        return {"data": _library(api)}
