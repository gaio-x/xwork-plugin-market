"""壁纸插件后端：记住「当前用哪张壁纸 + 遮罩多浓」，供主界面注入脚本取用。

四件事：
1. 内置 8 套渐变壁纸（纯 CSS 渐变，不联网、不引用外网图片）；
2. 记录用户选的壁纸与遮罩浓度 —— 存在插件的自配置里（data/plugin-state.json），
   **不写主程序的 settings.json**，也不碰别的插件的键；
3. `GET /state` 给注入脚本轮询（很小的 JSON），`GET /raw` 给本地图片的字节；
4. 命令 `bg.apply` / `bg.clear` / `bg.status`（设置页的「恢复默认背景」直接跑 bg.clear）。

两个必须交代的边界（都是契约限制，不是实现偷懒）：

* **图片为什么走 base64**：插件自有路由 `/api/plugins/<id>/x/...` 的返回值统一被包成
  `{"ok": true, "data": ...}` 并限制 4MB，没有"回原始字节"的通道；插件目录下的静态
  资源（`/api/plugins/<id>/files/...`）只服务插件自己目录里的文件。要把用户选的图片
  显示出来只有两条路 —— 复制进插件目录（要写盘）或编码成 data URL（只读）。本插件
  只申请 `fs.read`，所以走后者，单张图片上限 2MB（base64 后约 2.7MB，仍在 4MB 内）。
* **能选哪些图片**：`api.read_bytes` / `api.file_info` 都过工作区挂载白名单，所以图片
  必须落在「设置 → 文件与挂载」里列出的目录内，否则会被拒绝（这是主程序对 `fs.read`
  的统一约束，不是本插件另加的）。
"""
from __future__ import annotations

import base64
import hashlib
import threading

# 内置壁纸：id / 名称 / CSS 值。纯渐变，不依赖任何外部资源，深色浅色都不刺眼。
PRESETS = [
    {"id": "morning", "name": "晨雾",
     "css": "linear-gradient(135deg,#e9eff7 0%,#d2dfee 45%,#bacde1 100%)"},
    {"id": "deep-sea", "name": "深海",
     "css": "linear-gradient(160deg,#0f2233 0%,#16324a 50%,#1d4a63 100%)"},
    {"id": "graphite", "name": "石墨",
     "css": "linear-gradient(135deg,#24272c 0%,#343940 55%,#1b1e22 100%)"},
    {"id": "bamboo", "name": "竹青",
     "css": "linear-gradient(140deg,#e7efe5 0%,#c8dcc7 50%,#a4c4a6 100%)"},
    {"id": "dusk", "name": "暮色",
     "css": "linear-gradient(150deg,#2a2140 0%,#4a2f56 45%,#8a4a55 100%)"},
    {"id": "paper", "name": "宣纸",
     "css": "linear-gradient(135deg,#f7f3ea 0%,#efe6d6 60%,#e3d6bf 100%)"},
    {"id": "aurora", "name": "极光",
     "css": "linear-gradient(135deg,#0b1a2a 0%,#12454c 45%,#2f7d6b 100%)"},
    {"id": "sakura", "name": "樱粉",
     "css": "linear-gradient(135deg,#f8e9ef 0%,#efd2de 55%,#e0b9cb 100%)"},
]

IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")
IMAGE_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
              ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp"}

# 单张图片上限：base64 膨胀 4/3，2MB 原图 → 约 2.7MB 字符串，留在路由 4MB 上限之内。
MAX_IMAGE_BYTES = 2 * 1024 * 1024

DEFAULT_MASK = 30
MASK_MIN, MASK_MAX = 0, 80

# 最近一次编码好的图片：{rev, url}。键里带 mtime/size，换了图自然失效。
_CACHE: dict = {"rev": "", "url": ""}
_CACHE_LOCK = threading.Lock()


def _find_preset(preset_id: str) -> dict | None:
    for item in PRESETS:
        if item["id"] == preset_id:
            return item
    return None


def _clamp_mask(value) -> int:
    """遮罩浓度收敛到 0~80；脏值（空串/非法）回落到默认值而不是报错。"""
    try:
        num = int(round(float(value)))
    except (TypeError, ValueError):
        return DEFAULT_MASK
    return max(MASK_MIN, min(MASK_MAX, num))


def _conf(api) -> dict:
    return {
        "preset": str(api.get_setting("preset", "") or ""),
        "image_path": str(api.get_setting("imagePath", "") or ""),
        "mask": _clamp_mask(api.get_setting("mask", DEFAULT_MASK)),
    }


def _rev(*parts) -> str:
    """状态指纹：注入脚本只在指纹变化时重画，避免每 3 秒重设一次大图。"""
    text = "|".join(str(p) for p in parts)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]


def _probe(api, path: str) -> dict:
    """校验一张本地图片：存在、在挂载目录内、格式与体积都合适。不合法时抛中文错误。"""
    info = api.file_info(path)
    if info.get("is_dir"):
        raise ValueError("这是一个目录，请选择图片文件")
    ext = str(info.get("ext") or "").lower()
    if ext not in IMAGE_SUFFIXES:
        raise ValueError(f"不支持 {ext or '无扩展名'} 格式，请用 png / jpg / webp / gif / bmp")
    size = int(info.get("size") or 0)
    if size > MAX_IMAGE_BYTES:
        raise ValueError(f"图片 {size // 1024}KB 超过 {MAX_IMAGE_BYTES // 1024}KB 上限，请先压缩")
    return {"path": str(info.get("path") or path),
            "name": str(info.get("name") or ""),
            "mtime": int(info.get("mtime") or 0),
            "size": size, "ext": ext}


def _state(api) -> dict:
    """当前生效的壁纸状态。**永不抛错**：图片坏了就降级成"无背景"并带上原因。

    注入脚本每 3 秒调一次这个接口，抛错会变成日志洪水，也会让界面停在旧图上。
    """
    conf = _conf(api)
    out = {
        "mode": "none",              # none / preset / custom
        "preset": "", "preset_name": "", "preset_css": "",
        "image_path": conf["image_path"], "image_name": "", "image_size": 0,
        "mask": conf["mask"], "rev": _rev("none", conf["mask"]),
        "max_image_kb": MAX_IMAGE_BYTES // 1024,
        "error": "",
    }
    hit = _find_preset(conf["preset"])
    if hit:
        out.update({"mode": "preset", "preset": hit["id"], "preset_name": hit["name"],
                    "preset_css": hit["css"],
                    "rev": _rev("preset", hit["id"], conf["mask"])})
        return out
    if not conf["image_path"]:
        return out
    try:
        info = _probe(api, conf["image_path"])
    except Exception as exc:  # noqa: BLE001 文件被删/移出工作区：降级并说明原因
        out.update({"rev": _rev("broken", conf["image_path"], conf["mask"]),
                    "error": f"本地图片不可用：{exc}"})
        return out
    out.update({"mode": "custom", "image_path": info["path"], "image_name": info["name"],
                "image_size": info["size"],
                "rev": _rev("custom", info["path"], info["mtime"], info["size"],
                            conf["mask"])})
    return out


def _apply(api, *, preset=None, path=None, mask=None) -> dict:
    """写配置。preset 与 path 互斥：谁后应用谁生效，另一个清空（避免"看着是 A 实际是 B"）。"""
    if preset is not None:
        preset_id = str(preset or "").strip()
        if preset_id and not _find_preset(preset_id):
            raise ValueError(f"没有这套内置壁纸：{preset_id}")
        api.set_setting("preset", preset_id)
        if preset_id:
            api.set_setting("imagePath", "")
    if path is not None:
        raw_path = str(path or "").strip()
        if not raw_path:
            raise ValueError("请填写图片的绝对路径")
        info = _probe(api, raw_path)
        api.set_setting("imagePath", info["path"])
        api.set_setting("preset", "")
    if mask is not None:
        api.set_setting("mask", _clamp_mask(mask))
    return _state(api)


def register(api) -> None:
    @api.on_activate
    def _on_activate() -> None:
        st = _state(api)
        api.log(f"壁纸插件已激活（当前：{st['mode']}"
                f"{'/' + st['preset_name'] if st['preset_name'] else ''}）")

    @api.on_deactivate
    def _on_deactivate() -> None:
        # 停用后注入的 CSS/JS 会随界面重载一起消失；这里只把缓存放掉，不留图片常驻内存。
        with _CACHE_LOCK:
            _CACHE["rev"], _CACHE["url"] = "", ""
        api.log("壁纸插件已停用（界面重载后背景恢复默认）")

    # ---------------- 自有接口 ----------------
    @api.route("state")
    def _route_state(ctx: dict) -> dict:
        """GET /api/plugins/xwork.bg-image/x/state —— 注入脚本每 3 秒轮询的就是它。"""
        return _state(api)

    @api.route("presets")
    def _route_presets(ctx: dict) -> dict:
        """GET .../x/presets —— 内置壁纸清单（页面画缩略图用，不写死在 HTML 里）。"""
        return {"items": [{"id": p["id"], "name": p["name"], "css": p["css"]}
                          for p in PRESETS],
                "max_image_kb": MAX_IMAGE_BYTES // 1024,
                "mask_range": [MASK_MIN, MASK_MAX]}

    @api.route("raw")
    def _route_raw(ctx: dict) -> dict:
        """GET .../x/raw —— 本地图片编成 data URL。

        失败不抛异常而是回 `{"error": "..."}`：这个接口由注入脚本调用，抛错只会变成
        浏览器控制台里一条看不懂的 400，回一句话反而能在页面上直接显示。
        """
        conf = _conf(api)
        if not conf["image_path"]:
            return {"error": "", "data_url": "", "rev": "", "name": "", "bytes": 0}
        try:
            info = _probe(api, conf["image_path"])
            rev = _rev("custom", info["path"], info["mtime"], info["size"], conf["mask"])
            with _CACHE_LOCK:
                if _CACHE["rev"] == rev and _CACHE["url"]:
                    return {"error": "", "data_url": _CACHE["url"], "rev": rev,
                            "name": info["name"], "bytes": info["size"]}
            raw = api.read_bytes(info["path"], max_bytes=MAX_IMAGE_BYTES)
        except Exception as exc:  # noqa: BLE001 —— 统一转成给用户看的一句话
            return {"error": str(exc), "data_url": "", "rev": "", "name": "", "bytes": 0}
        mime = IMAGE_MIME.get(info["ext"], "image/png")
        url = f"data:{mime};base64," + base64.b64encode(raw).decode("ascii")
        with _CACHE_LOCK:
            _CACHE["rev"], _CACHE["url"] = rev, url
        return {"error": "", "data_url": url, "rev": rev, "name": info["name"],
                "bytes": info["size"]}

    @api.route("apply", methods=("POST",))
    def _route_apply(ctx: dict) -> dict:
        """POST .../x/apply —— 页面唯一的写入口：{preset?} / {path?} / {mask?} / {clear?}。

        `clear: true` 表示"恢复默认背景"（内置壁纸与本地图片一起清掉，遮罩保留）。
        """
        body = ctx.get("body") or {}
        if body.get("clear"):
            api.set_setting("preset", "")
            api.set_setting("imagePath", "")
            if "mask" in body:
                api.set_setting("mask", _clamp_mask(body.get("mask")))
            return _state(api)
        return _apply(api,
                      preset=body.get("preset") if "preset" in body else None,
                      path=body.get("path") if "path" in body else None,
                      mask=body.get("mask") if "mask" in body else None)

    # ---------------- 命令 ----------------
    @api.command("bg.apply", "壁纸：换一张", group="插件",
                 description="应用内置壁纸（preset）或本地图片（path），可选同时改遮罩（mask）",
                 args={"preset": "str", "path": "str", "mask": "str"},
                 keywords="壁纸 背景 背景图 换图")
    def apply(preset: str = "", path: str = "", mask: str = "") -> dict:
        if not preset and not path and mask == "":
            raise ValueError("请提供内置壁纸 id（preset）或本地图片路径（path）")
        return {"data": _apply(api,
                               preset=preset if preset else None,
                               path=path if path else None,
                               mask=mask if mask != "" else None)}

    @api.command("bg.clear", "壁纸：恢复默认背景", group="插件",
                 description="清掉壁纸，界面回到纯色背景（遮罩浓度保留）",
                 keywords="壁纸 恢复 默认 清除 背景")
    def clear() -> dict:
        api.set_setting("preset", "")
        api.set_setting("imagePath", "")
        return {"data": _state(api)}

    @api.command("bg.status", "壁纸：当前状态", group="插件", silent=True,
                 description="返回当前壁纸模式、名称与遮罩浓度",
                 keywords="壁纸 状态 当前")
    def status() -> dict:
        return {"data": _state(api)}
