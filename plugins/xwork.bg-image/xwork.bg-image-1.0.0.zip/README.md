# 壁纸（xwork.bg-image）

> 版本 v1.0.0 ｜ 命名空间 `bg` ｜ 权限 `ui.inject_global`、`fs.write`

## 这个插件做什么

给主界面换一张背景：8 套内置渐变，也可以上传自己的图片或视频（图片可先裁剪），再压一层浓度可调的遮罩；改完立刻生效，不用重启界面。
它只动背景 —— 布局、按钮、字体一律不变。壁纸生效期间卡片与外壳会转成**半透明**（`--surface` / `--surface-2` 换成 78%~80% 的 rgba），
让壁纸从外壳到卡片连续铺满；关掉壁纸后这些覆盖全部失效，界面与没有壁纸时完全一致。觉得正文不够清楚就把遮罩浓度调高。

## 怎么用

两个入口，打开的是同一个弹窗：「设置 → 外观 → 背景图片」→「打开壁纸设置」；「插件」页找到「壁纸」→ 打开插件页（弹窗标题为「壁纸设置」）。
弹窗里：点缩略图换内置壁纸；「选择图片」→ 拉裁剪框 →「应用并设为壁纸」；「选择视频」（mp4/webm/ogg/mov/m4v）直接上传生效；
拖「遮罩浓度」（0~80）与「铺满方式」（铺满 / 完整显示 / 平铺）；「恢复默认」回到纯色背景，已保存的文件不删。
裁剪支持按比例约束（默认跟随窗口比例，另有 16:9 / 16:10 / 4:3 / 3:2 / 1:1 与自由），裁剪过程可在右上角实时预览结果。
首次启用要在插件页逐项授权，其中「改写全局界面」（`ui.inject_global`）是高危项，需勾选"我了解风险"。

## 提供的能力

| 类型 | id / 路径 | 说明 |
|---|---|---|
| 命令 | `bg.apply` / `bg.clear` / `bg.status` / `bg.list` | 换一张（`preset` 或 `mediaUrl`，可带 `mask` / `fit`）／恢复默认（不删文件）／当前状态（静默）／已保存清单（`active` 标当前） |
| 接口 | `GET .../x/state` | `mode`（none/preset/image/video）、`preset_css`、`media_url`、`media_kind`、`mask`、`fit`、`rev`、`error` |
| 接口 | `GET .../x/presets` | 内置壁纸清单 + 遮罩范围 / 铺满选项 / 上传上限 |
| 接口 | `GET .../x/library` | 已保存的图片与视频 |
| 接口 | `POST .../x/apply` | 写入口：`preset` 与 `mediaUrl` 互斥，另可带 `mask` / `fit` / `clear` |
| 接口 | `POST .../x/remove` | 从清单移除，回 `files[].delete_url` 供前端删盘 |

`...` 即 `/api/plugins/xwork.bg-image`。图片与视频走主程序的**插件媒体存储**（`POST/GET/DELETE /api/plugins/xwork.bg-image/media[/<文件名>]`）：
原始字节收发、支持 Range（视频能拖进度条），落地在 `data/plugins/xwork.bg-image/media/` —— 图片存裁剪后的 PNG（选区拉满全图即不裁剪），
视频保留原文件，都不转码、不上传网络。**删除壁纸会一并删掉对应文件**：前端按 `remove` 返回的 `delete_url` 调 DELETE，插件只改状态。

## 权限与安全

| 权限 | 为什么需要 |
|---|---|
| `ui.inject_global`（高危） | 唯一能把样式/脚本注入主界面的正式通道：建一个 `#xwork-bg-layer` 背景层（`position:fixed; z-index:0`），图片用 `background-image`（地址带 `?t=` 令牌，否则 `/api/` 下必然 401）、视频用 `<video muted loop playsinline>`，遮罩用该层的 `::after` 叠在壁纸之上；壁纸生效期间（`html[data-bg-image="on"]`）再把外壳 `.shell` 抬到 `z-index:1`（内容整体盖在背景层之上，不依赖负 `z-index` 那条脆弱链）、把 `--surface` / `--surface-2` 换成半透明，壳层专用的 `--shell-bg` 同步换档（**不是全透明**：全透明会让导航文字直接压在壁纸上，深色壁纸下对比度只有 2.6:1） |
| `fs.write` | 媒体路由的上传与删除门槛；壁纸只存本机 `data/` 下，不读用户其它目录，也不出网 |

不申请 `fs.read` / `network` / `system.exec` / `command.intercept`：图片由浏览器选好文件后直接上传，插件不经手读盘。
注入只碰背景层与 `html[data-bg-image="on"]` 作用域内的颜色变量：壁纸生效时让出 `body` 与外壳/卡片的实色背景，关掉立即全部恢复；
不改布局、不绑别人的事件、不动主程序 `web/style.css` 的默认值。

## 配置项与设置页的关系

`contributes.settings` 里的 `mask` / `fit` / `wallpaper` 三项**仍然保留，但不再渲染到设置页**（清单里没有
`contributes.settings_sections`）。原因是后端 `api.set_setting` 对未在清单里声明的 key 直接抛错，删掉声明会让
插件的配置存储整体不可用。这三项的实际角色：

- `mask` / `fit`：壁纸设置界面上的两个控件直接读写它们，属于运行时状态；
- `wallpaper`：当前内置壁纸 / 当前媒体地址 / 已保存清单，纯内部状态，用户不需要看见。

用户感知的入口只有两个：设置「外观 → 背景图片 → 打开壁纸设置」，以及插件页的「壁纸设置」页面。

## 文件

`manifest.json` 清单（id、命名空间、两条权限、命令 / 页面 / 配置项 / 注入声明）；`backend.py` 命令与自有接口、内置渐变表、壁纸状态与已保存清单；
`page.html` / `page.js` / `style.css` 壁纸设置界面（缩略图、上传、裁剪弹窗、遮罩与铺满方式；`page.html` 里的资源引用必须由**内联引导脚本**
带 token 动态插入，否则相对路径会丢掉 `?t=`、在 `/api/` 鉴权下拿到 401）；`inject.css` / `inject.js` 全局注入（背景层 + 外壳/卡片半透明 + 轮询 `/x/state`）；`README.md` 本文件。
