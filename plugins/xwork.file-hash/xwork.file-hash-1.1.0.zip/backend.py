"""文件哈希插件：MD5 / SHA1 / SHA256。

给网络运维的场景：下载的固件、补丁包、设备配置备份，先用哈希核对一致性。
文件访问走 api.read_bytes（受工作区白名单 + fs.read 权限约束），不自行 open。
"""
from __future__ import annotations

import hashlib

MAX_BYTES = 64 * 1024 * 1024   # 单文件最多 64MB（够绝大多数固件/补丁）


def _digest(api, path, algo):
    data = api.read_bytes(path, max_bytes=MAX_BYTES)
    h = hashlib.new(algo)
    h.update(data)
    return h.hexdigest()


def register(api):
    def _mk(cmd_id, title, algo, keywords):
        @api.command(cmd_id, title, group="哈希",
                     description=f"计算文件的 {algo.upper()} 摘要（校验完整性）",
                     args={"path": "str"}, silent=True, keywords=keywords)
        def _fn(path: str) -> dict:
            info = api.file_info(path)
            digest = _digest(api, path, algo)
            return {"name": info["name"], "size": info["size"],
                    "algorithm": algo.upper(), "digest": digest}
        return _fn

    _mk("hash.md5", "计算 MD5", "md5", "md5 哈希 校验")
    _mk("hash.sha1", "计算 SHA1", "sha1", "sha1 哈希 校验")
    _mk("hash.sha256", "计算 SHA256", "sha256", "sha256 哈希 校验")
