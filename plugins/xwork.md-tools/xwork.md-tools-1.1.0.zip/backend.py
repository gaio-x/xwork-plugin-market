"""示例插件：Markdown 小工具。

它只做三件事，但把  插件骨架的三个扩展点都用上了：
1. contributes.commands   —— 命令面板/插件页可直接执行
2. contributes.file_actions —— 文件页右键菜单按 when 条件出现
3. contributes.cards      —— 首页可添加"插件卡片"

写插件时请记住两条硬规矩：
- **所有文件访问都走 api 对象**（api.read_text / api.create_file …），不要自己 open。
  api 会做工作区白名单校验和权限校验；绕过它就等于绕过了安全底线。
- 能力必须先在 manifest.contributes 里声明，没声明的命令 register 时会直接报错。
"""
from __future__ import annotations

import html
import os

MAX_CHARS = 3000       # 单次只读前 3000 字，避免把几百 MB 文件读进内存
MAX_SCAN_FILES = 200   # 统计卡片的扫描上限：首页卡片必须秒回，不能扫全盘


def _count(text: str) -> dict:
    lines = text.count("\n") + (1 if text else 0)
    # 中英文混排的"字数"口径：中文按字算，英文按空格分词后再算词
    cjk = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
    words = len([w for w in text.replace("\n", " ").split(" ") if w.strip()])
    return {"chars": len(text), "lines": lines, "cjk": cjk, "words": words}


def register(api):
    @api.command("md.stats", "统计 Markdown 字数", group="插件",
                 description="统计 .md/.txt 的字符数、行数与中文字数",
                 args={"path": "str"}, silent=True, keywords="字数 统计 word count")
    def md_stats(path: str) -> dict:
        data = api.read_text(path)
        text = str(data.get("content") or "")[:MAX_CHARS]
        info = _count(text)
        return {"name": os.path.basename(str(data.get("path") or path)),
                "truncated": bool(data.get("truncated")) or len(
                    str(data.get("content") or "")) > MAX_CHARS,
                **info}

    @api.command("md.export_html", "导出为 HTML", group="插件",
                 description="把 Markdown 原文包成单文件 HTML，写在同目录（同名已存在则失败）",
                 args={"path": "str"}, keywords="导出 html export")
    def md_export_html(path: str) -> dict:
        data = api.read_text(path)
        info = api.file_info(path)
        text = str(data.get("content") or "")
        title = html.escape(info["name"])
        doc = (
            "<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"utf-8\">\n"
            f"<title>{title}</title>\n"
            "<style>body{max-width:820px;margin:40px auto;padding:0 20px;"
            "font:16px/1.75 -apple-system,'Microsoft YaHei',sans-serif;color:#1f2328}"
            "pre{white-space:pre-wrap;word-break:break-word;background:#f6f8fa;"
            "padding:16px;border-radius:8px}</style>\n</head>\n<body>\n"
            f"<h1>{title}</h1>\n<pre>{html.escape(text)}</pre>\n</body>\n</html>\n"
        )
        parent = os.path.dirname(info["path"])
        target_name = os.path.splitext(info["name"])[0] + ".html"
        created = api.create_file(parent, target_name, doc)
        return {"path": created["path"], "size": created["size"], "from": info["path"]}

    @api.command("md.count_all", "统计全部 Markdown", group="插件",
                 description="统计挂载目录前两层里的 Markdown 文件数与字数（最多 200 个文件）",
                 silent=True, keywords="统计 全部 markdown")
    def md_count_all() -> dict:
        files = 0
        chars = 0
        skipped = 0
        for root in api.workspace_roots():
            queue = [(root, 0)]
            while queue and files < MAX_SCAN_FILES:
                current, depth = queue.pop(0)
                try:
                    entries = api.list_dir(current)
                except Exception:  # noqa: BLE001 单个目录没权限就跳过，不影响整体统计
                    skipped += 1
                    continue
                for ent in entries:
                    if ent["is_dir"]:
                        if depth < 1:            # 只往下走两层
                            queue.append((ent["path"], depth + 1))
                        continue
                    if ent["ext"] not in (".md", ".markdown"):
                        continue
                    if files >= MAX_SCAN_FILES:
                        break
                    files += 1
                    try:
                        text = str(api.read_text(ent["path"]).get("content") or "")
                        chars += len(text[:MAX_CHARS])
                    except Exception:  # noqa: BLE001
                        skipped += 1
        return {"files": files, "chars": chars, "skipped": skipped,
                "capped": files >= MAX_SCAN_FILES}
