"""文本工具插件：编码检测 / 统计 / Base64 / JSON 格式化 / 按行去重。

全部文件访问走 api（read_text / create_file / file_info），不做越权操作；
「另存」类动作不覆盖原文件，写一个新文件，同名已存在则报错，由用户决定。
"""
from __future__ import annotations

import base64
import json
import os
import re

MAX_CHARS = 2 * 1024 * 1024      # 单次最多读 2MB，避免大文件拖垮插件


def _read(api, path):
    data = api.read_text(path, max_bytes=MAX_CHARS)
    return str(data.get("content") or ""), data


def _save(api, info, stem, suffix, content):
    """在原文件同目录另存一个新文件，返回 (path, size)。"""
    parent = os.path.dirname(info["path"])
    target = f"{stem}{suffix}"
    created = api.create_file(parent, target, content)
    return created["path"], created["size"]


def register(api):
    @api.command("text.stats", "统计文本行数/字数", group="文本",
                 description="统计文本文件的字符数、行数、中文字数、英文词数",
                 args={"path": "str"}, silent=True, keywords="统计 行数 字数 word count")
    def text_stats(path: str) -> dict:
        text, data = _read(api, path)
        lines = text.count("\n") + (1 if text else 0)
        cjk = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
        words = len([w for w in re.sub(r"\s+", " ", text).split(" ") if w.strip()])
        return {"name": os.path.basename(str(data.get("path") or path)),
                "chars": len(text), "lines": lines, "cjk": cjk, "words": words,
                "truncated": bool(data.get("truncated"))}

    @api.command("text.dedup_lines", "按行去重", group="文本",
                 description="保留首次出现的行，去重后另存为 *_dedup.*",
                 args={"path": "str"}, keywords="去重 dedup")
    def text_dedup(path: str) -> dict:
        text, data = _read(api, path)
        info = api.file_info(path)
        lines = text.splitlines()
        seen = set()
        out = []
        for ln in lines:
            if ln not in seen:
                seen.add(ln)
                out.append(ln)
        stem = os.path.splitext(info["name"])[0]
        suffix = os.path.splitext(info["name"])[1]
        saved, size = _save(api, info, stem + "_dedup", suffix, "\n".join(out) + "\n")
        return {"path": saved, "size": size, "lines_before": len(lines),
                "lines_after": len(out), "removed": len(lines) - len(out)}

    @api.command("text.json_format", "格式化 JSON", group="文本",
                 description="把 JSON 重新缩进排版，另存为 *_pretty.json",
                 args={"path": "str"}, keywords="json 格式化 format")
    def text_json_format(path: str) -> dict:
        text, data = _read(api, path)
        info = api.file_info(path)
        try:
            obj = json.loads(text)
            pretty = json.dumps(obj, ensure_ascii=False, indent=2)
        except (json.JSONDecodeError, ValueError) as exc:
            raise RuntimeError(f"JSON 解析失败：{exc}")
        stem = os.path.splitext(info["name"])[0]
        saved, size = _save(api, info, stem + "_pretty", ".json", pretty)
        return {"path": saved, "size": size, "input_chars": len(text)}

    @api.command("text.base64_encode", "Base64 编码", group="文本",
                 description="把文本内容做 Base64 编码，另存为 *_b64.txt",
                 args={"path": "str"}, keywords="base64 编码 encode")
    def text_b64_encode(path: str) -> dict:
        text, data = _read(api, path)
        info = api.file_info(path)
        encoded = base64.b64encode(text.encode("utf-8")).decode("ascii")
        stem = os.path.splitext(info["name"])[0]
        saved, size = _save(api, info, stem + "_b64", ".txt", encoded)
        return {"path": saved, "size": size}

    @api.command("text.base64_decode", "Base64 解码", group="文本",
                 description="把 Base64 文本解码，另存为 *_decoded.txt",
                 args={"path": "str"}, keywords="base64 解码 decode")
    def text_b64_decode(path: str) -> dict:
        text, data = _read(api, path)
        info = api.file_info(path)
        try:
            decoded = base64.b64decode(text.strip(), validate=True)
        except Exception as exc:  # noqa: BLE001 非法 base64 给中文提示
            raise RuntimeError(f"Base64 解码失败：{type(exc).__name__}")
        try:
            decoded_text = decoded.decode("utf-8")
        except UnicodeDecodeError:
            decoded_text = decoded.decode("latin-1")
        stem = os.path.splitext(info["name"])[0]
        saved, size = _save(api, info, stem + "_decoded", ".txt", decoded_text)
        return {"path": saved, "size": size}
