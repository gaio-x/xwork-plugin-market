# 文本工具（xwork.text-tools）

> 版本 v1.0.0 ｜ 命名空间 `text` ｜ 权限 `fs.read`、`fs.write`

## 这个插件做什么

处理日志和配置时那些"一次性的小活"：这个 `.log` 有多少行、多少字；几百行重复
记录怎么快速压掉；一坨没缩进的 JSON 怎么排开看清楚；一段文本要转成 Base64 贴进
别处，或者把别人给的 Base64 解回来。

五个命令都是围绕「原文件不动、结果另存」设计的：去重存 `*_dedup.*`、格式化存
`*_pretty.json`、编码存 `*_b64.txt`、解码存 `*_decoded.txt`，同名已存在就报错，
绝不悄悄覆盖你的原文件。

## 怎么用

**命令面板**：搜「统计」「去重」「Base64」「JSON」可找到五条命令，都需要填文件路径。

**文件右键**：四个动作按扩展名分别出现——「统计行数/字数」覆盖 `.txt` `.log` `.md`
`.markdown` `.json` `.csv` `.cfg` `.conf` `.ini` `.xml` `.yaml` `.yml`；「按行去重（另存）」
只对 `.txt` `.log` `.csv` `.cfg` `.conf` `.ini`；「Base64 编码（另存）」只对 `.txt` `.log`
`.md` `.cfg` `.conf` `.ini`；「格式化 JSON（另存）」只在 `.json` 上出现。**Base64 解码只能
在命令面板用**——它没有绑定右键动作。

**插件页**：没有独立页面，只在插件页启用并授予权限。

## 提供的能力

| 命令 id | 名称 | 参数 | 说明 |
|---|---|---|---|
| `text.stats` | 统计文本行数/字数 | `path: str` | 统计文本文件的字符数、行数、中文字数、英文词数 |
| `text.dedup_lines` | 按行去重 | `path: str` | 保留首次出现的行，去重后另存为 `*_dedup.*` |
| `text.json_format` | 格式化 JSON | `path: str` | 把 JSON 重新缩进排版，另存为 `*_pretty.json` |
| `text.base64_encode` | Base64 编码 | `path: str` | 把文本内容做 Base64 编码，另存为 `*_b64.txt` |
| `text.base64_decode` | Base64 解码 | `path: str` | 把 Base64 文本解码，另存为 `*_decoded.txt` |

## 权限与安全

`fs.read` 用于读取原文，`fs.write` 用于写"另存"出来的新文件。单次读取上限 2MB，
超出不处理；写入只发生在原文件同目录且不覆盖同名文件；出错一律返回中文原因。不联网。

## 文件

- `manifest.json`：清单，声明五个命令、四个文件动作与权限。
- `backend.py`：全部实现；读取走 `api.read_text`，另存走 `api.create_file`（不覆盖同名）。
