"""能力缝演示插件。

它把宿主 `core/plugin/seam.py::SEAMS` 里的 **18 个能力缝全部**各挂一个实现，用来验证
"插件能不能真的接管内置能力"。**这是一个演示/验收夹具，不是给日常使用的插件**：
启用后预览、问答、AI 调用、笔记解析、主题色都会变。看完请到插件页停用。

写自己的插件时，请照这里的两条规矩来：
1. `@api.provide(缝名)` 之前，manifest.contributes.providers 里必须先声明，
   并且要申请该缝对应的权限——授权页要能提前告诉用户"这个插件要接管什么"。
2. provider 返回 `None` 表示"我不处理这个"，宿主会去找下一个插件或走内置实现。
   返回 dict 才表示"这次由我负责"。**抛异常只会让宿主回退，不会让软件坏掉**。

演示的克制：笔记解析/渲染这两条 replace 缝只在正文带 `XWORK-DEMO` 标记时接管，
普通文档一律返回 None 走内置实现；反链排序只改顺序、绝不增删条目。
这样即使忘了停用，也不会把现有笔记数据写坏。面板（panel.html）通过插件自有接口
`/x/seams` 读调用计数、`/x/try` 喂样例载荷直接触发一次、`/x/reset` 清零。
"""
from __future__ import annotations

import functools

# 演示用的自定义格式：纯文本，每行一个块
DEMO_SUFFIX = ".demo"
# 笔记缝的接管开关：正文里有这个标记才启用自定义解析/渲染
DEMO_MARK = "XWORK-DEMO"

# 18 条缝：顺序与 core/plugin/seam.py::SEAMS 一致。manifest 里的声明是授权凭据，
# 这里只是面板展示用的中文标签与触发提示，改缝名时三处要一起改。
SEAM_IDS = (
    "fs.preview", "fs.extract", "fs.batch", "fs.index",
    "kb.chunker", "kb.reranker", "kb.answer_post",
    "notes.parser", "notes.renderer", "notes.backlink_rank",
    "ai.provider", "ai.guard", "netops.probe", "apps.kind",
    "command.provide", "theme.tokens", "ui.decorator", "shell.action",
)
SEAM_LABELS = {
    "fs.preview": "文件预览渲染", "fs.extract": "文档文本抽取",
    "fs.batch": "批量操作类型", "fs.index": "文件索引排序与过滤",
    "kb.chunker": "分块策略", "kb.reranker": "检索结果重排",
    "kb.answer_post": "回答后处理", "notes.parser": "笔记块解析",
    "notes.renderer": "笔记块渲染落盘", "notes.backlink_rank": "反链排序",
    "ai.provider": "大模型供应商", "ai.guard": "内容护栏",
    "netops.probe": "自定义探测方法", "apps.kind": "应用启动类型",
    "command.provide": "接管内置命令", "theme.tokens": "主题变量",
    "ui.decorator": "界面元素修饰", "shell.action": "托盘/热键/窗口",
}
SEAM_HOW = {
    "fs.preview": "打开一个 .demo 文件的预览",
    "fs.extract": "把 .demo 文件加入知识库",
    "fs.batch": "文件页批量操作选「统计所选文件」",
    "fs.index": "打开任意目录的文件列表",
    "kb.chunker": "知识库入库一份文档",
    "kb.reranker": "知识库检索一次",
    "kb.answer_post": "知识库问答一次",
    "notes.parser": "打开正文含 XWORK-DEMO 的笔记",
    "notes.renderer": "编辑并保存含 XWORK-DEMO 的笔记",
    "notes.backlink_rank": "查看某条笔记的反链",
    "ai.provider": "在对话页发一条消息",
    "ai.guard": "发送含 SECRET 的内容",
    "netops.probe": "运维页用 echo 方法探测",
    "apps.kind": "用 echo 类型启动一个条目",
    "command.provide": "命令面板执行掩码换算",
    "theme.tokens": "切换浅色 / 深色主题",
    "ui.decorator": "打开含 .demo 文件的目录",
    "shell.action": "展开系统托盘菜单",
}

# 面板「试一次」用的最小样例载荷。只列能纯内存跑通的缝：
# fs.preview / fs.extract / fs.batch 需要宿主读真实文件，请到对应页面操作（面板会提示）。
SEAM_SAMPLE = {
    "fs.index": {"entries": [{"name": "a.demo", "ext": ".demo", "is_dir": False},
                             {"name": "b.txt", "ext": ".txt", "is_dir": False}]},
    "kb.chunker": {"blocks": [{"text": "演示分块样例文本", "heading_path": "",
                               "locator": {"line": 1}}]},
    "kb.reranker": {"items": [{"chunk_id": "c1", "path": "b.md", "text": "x"},
                              {"chunk_id": "c2", "path": "a.md", "text": "y"}]},
    "kb.answer_post": {"question": "演示问题", "answer": "演示答案"},
    "notes.parser": {"title": "演示笔记", "body": "XWORK-DEMO 第一行\n第二行"},
    "notes.renderer": {"title": "演示笔记",
                       "blocks": [{"type": "p", "raw": "XWORK-DEMO 第一行",
                                   "text": "XWORK-DEMO 第一行", "level": 0}]},
    "notes.backlink_rank": {
        "doc_id": "d1", "block_id": "b1",
        "items": [{"doc_id": "x", "block_id": "b2", "doc_title": "乙笔记", "excerpt": ""},
                  {"doc_id": "z", "block_id": "b3", "doc_title": "甲笔记", "excerpt": ""}],
    },
    "ai.provider": {"messages": [{"role": "user", "content": "你好"}]},
    "ai.guard": {"stage": "request", "text": "这里含 SECRET 演示词"},
    "netops.probe": {"method": "echo", "target": "127.0.0.1"},
    "apps.kind": {"kind": "echo", "target": "demo"},
    "command.provide": {"command": "netops.mask_prefix", "args": {"mask": "255.255.255.0"}},
    "theme.tokens": {"theme": "light"},
    "ui.decorator": {"page": "files"},
    "shell.action": {"hook": "tray.menu"},
}

# 每个缝的调用次数（内存记账，重启即清空；停用不清零，方便观察累计效果）。
_CALLS: dict[str, int] = {}
# 缝 id -> 包装后的函数。面板「试一次」直接调它，等价于宿主喂一份样例载荷。
_TRYABLE: dict[str, object] = {}


def _count(seam_id: str):
    """给 provider 套一层计数；同时登记到 _TRYABLE 供面板直接触发样例调用。

    必须放在 @api.provide 下面（更靠近 def）：装饰器自下而上生效，
    api.provide 收到的是包装后的函数，宿主每次调用才会经过计数。
    """
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(payload):
            _CALLS[seam_id] = _CALLS.get(seam_id, 0) + 1
            return fn(payload)
        _TRYABLE[seam_id] = wrapper
        return wrapper
    return deco


def catalog(plugin_id: str) -> dict:
    """面板 / demo.info 共用的快照：18 条缝、各自调用次数、能否在面板直接试。"""
    return {
        "plugin": plugin_id,
        "total": len(SEAM_IDS),
        "total_calls": sum(_CALLS.values()),
        "seams": [
            {"id": sid, "label": SEAM_LABELS.get(sid, sid),
             "calls": _CALLS.get(sid, 0), "tryable": sid in SEAM_SAMPLE,
             "how": SEAM_HOW.get(sid, "")}
            for sid in SEAM_IDS
        ],
        "note": "停用本插件后，以上接管立即消失，宿主恢复内置实现",
    }


def register(api):
    # ---------------------------------------------------------------- 插件自有接口（面板取数）
    @api.route("seams")
    def _route_seams(ctx: dict) -> dict:
        """GET /api/plugins/xwork.seam-demo/x/seams —— 18 条缝的接管与调用情况。"""
        return catalog(api.id)

    @api.route("reset", methods=("POST",))
    def _route_reset(ctx: dict) -> dict:
        """POST /x/reset —— 清空面板里的调用计数（不动宿主那边的 provider 统计）。"""
        n = sum(_CALLS.values())
        _CALLS.clear()
        return {"cleared": n, **catalog(api.id)}

    @api.route("try", methods=("POST",))
    def _route_try(ctx: dict) -> dict:
        """POST /x/try —— 喂一份样例载荷直接调一次 provider，验证返回结构。

        需要读真实文件的 4 条缝不在 SEAM_SAMPLE 里，面板会如实提示"到对应页面操作"。
        """
        sid = str((ctx.get("body") or {}).get("seam") or "")
        if sid not in SEAM_SAMPLE:
            return {"ok": False, "seam": sid,
                    "error": "这条缝需要宿主读真实文件，请到对应页面操作（见「怎么触发」）"}
        fn = _TRYABLE.get(sid)
        if fn is None:
            return {"ok": False, "seam": sid, "error": "这条缝尚未注册"}
        try:
            result = fn(dict(SEAM_SAMPLE[sid]))
        except Exception as exc:  # noqa: BLE001 演示接口出错也要给用户看得懂的原因
            return {"ok": False, "seam": sid, "error": f"{type(exc).__name__}: {exc}"}
        return {"ok": True, "seam": sid, "result": result,
                "calls": _CALLS.get(sid, 0), "note": "这是样例载荷，不是宿主真实调用"}

    # ---------------------------------------------------------------- 命令
    @api.command("demo.info", "能力缝演示：当前接管情况",
                 description="列出本插件挂了哪些能力缝，以及每条缝被调用的次数")
    def info():
        return {"data": catalog(api.id)}

    @api.command("demo.tray_hello", "演示：托盘菜单点了会跑这个命令",
                 description="从托盘菜单触发，验证 shell.action 缝能执行插件命令")
    def tray_hello():
        api.log("托盘菜单触发了 demo.tray_hello")
        return {"data": {"message": "托盘菜单 → 插件命令 已打通"}}

    # ---------------------------------------------------------------- 文件
    @api.provide("fs.preview", "demo")
    @_count("fs.preview")
    def preview(payload):
        """只处理 .demo；其它扩展名返回 None，交给内置预览。"""
        if payload.get("ext") != DEMO_SUFFIX:
            return None
        try:
            got = api.read_text(payload["path"], max_bytes=64 * 1024)
        except Exception:
            return {"ok": False, "error": "演示插件读不到这个文件（检查是否在挂载目录内）"}
        lines = (got.get("content") or "").splitlines()
        blocks = [{"text": ln, "locator": {"line": i + 1},
                   "heading_path": ""} for i, ln in enumerate(lines) if ln.strip()]
        return {"ok": True, "data": {
            "kind": "demo", "fidelity": "plugin", "blocks": blocks[:400],
            "warning": "由「能力缝演示」插件渲染（内置预览不认识 .demo）",
        }}

    @api.provide("fs.extract", "demo")
    @_count("fs.extract")
    def extract(payload):
        """知识库入库时解析 .demo：一行一块，带行号定位。"""
        if payload.get("ext") != DEMO_SUFFIX:
            return None
        try:
            got = api.read_text(payload["path"], max_bytes=2 * 1024 * 1024)
        except Exception:
            return None
        blocks = []
        for i, line in enumerate((got.get("content") or "").splitlines(), 1):
            if line.strip():
                blocks.append({"text": line, "locator": {"line": i},
                               "heading_path": ""})
        if not blocks:
            return None
        return {"kind": "demo", "title": payload.get("name") or "demo",
                "blocks": blocks, "warning": "由演示插件解析"}

    @api.provide("fs.batch", "count")
    @_count("fs.batch")
    def batch_count(payload):
        """演示"插件新增一种批量操作"：统计所选路径的数量与总体积。"""
        if payload.get("action") != "count":
            return None
        paths = payload.get("paths") or []
        total = 0
        dirs = files = 0
        for p in paths:
            try:
                info = api.file_info(p)
            except Exception:
                continue
            if info["is_dir"]:
                dirs += 1
            else:
                files += 1
                total += info["size"]
        return {"ok": True, "data": {"dirs": dirs, "files": files,
                                     "bytes": total, "by": "demo.count"}}

    @api.provide("fs.index", "tag")
    @_count("fs.index")
    def index_tag(payload):
        """演示"给列表补派生字段"：给每个条目加 demo_tag（前端可用来做筛选）。"""
        entries = payload.get("entries") or []
        if not entries:
            return None
        out = []
        for e in entries:
            item = dict(e)
            item["demo_tag"] = "dir" if e.get("is_dir") else (e.get("ext") or "noext")
            out.append(item)
        return {"entries": out}

    # ---------------------------------------------------------------- 知识库
    @api.provide("kb.chunker", "fixed")
    @_count("kb.chunker")
    def chunker(payload):
        """定长分块：每 300 字一块，不做语义切分（只为证明"分块可被接管"）。"""
        blocks = payload.get("blocks") or []
        if not blocks:
            return None
        chunks = []
        for b in blocks:
            text = (b.get("text") or "").strip()
            for i in range(0, len(text), 300):
                piece = text[i:i + 300].strip()
                if len(piece) < 2:
                    continue
                chunks.append({"text": piece,
                               "heading_path": b.get("heading_path") or "",
                               "locator": b.get("locator") or {}})
        return {"chunks": chunks} if chunks else None

    @api.provide("kb.reranker", "reverse")
    @_count("kb.reranker")
    def rerank(payload):
        """按路径字母序重排——演示"重排只能改顺序，不能弄丢结果"。"""
        items = payload.get("items") or []
        if not items:
            return None
        order = [i["chunk_id"] for i in sorted(items, key=lambda x: x.get("path") or "")]
        return {"chunk_ids": order, "note": "演示插件按路径重排"}

    @api.provide("kb.answer_post", "notice")
    @_count("kb.answer_post")
    def answer_post(payload):
        """在答案末尾追加一句附注（设置项可改内容）。"""
        answer = payload.get("answer") or ""
        notice = api.get_setting("notice") or ""
        if not answer or not notice:
            return None
        return {"answer": f"{answer}\n\n{notice}"}

    # ---------------------------------------------------------------- 笔记
    @api.provide("notes.parser", "demo")
    @_count("notes.parser")
    def note_parse(payload):
        """只在正文带 XWORK-DEMO 标记时接管：一行一块，保留行号与原文。

        普通笔记一律返回 None 走内置 Markdown 解析——replace 缝若不设边界，
        用户启用一次演示插件就会把全部笔记的块模型换掉。
        """
        body = str(payload.get("body") or "")
        if DEMO_MARK not in body:
            return None
        blocks = []
        for i, line in enumerate(body.splitlines(), 1):
            if not line.strip():
                continue
            blocks.append({"type": "p", "text": line, "raw": line,
                           "level": 0, "depth": 0, "line_start": i,
                           "line_end": i, "heading_path": ""})
        return {"blocks": blocks} if blocks else None

    @api.provide("notes.renderer", "demo")
    @_count("notes.renderer")
    def note_render(payload):
        """带标记的笔记才接管：逐块用 raw 原样拼回，末尾加一行说明，不改任何块内容。"""
        blocks = payload.get("blocks") or []
        if not blocks or not any(DEMO_MARK in str(b.get("raw") or "") for b in blocks):
            return None
        parts = [str(b.get("raw") or b.get("text") or "") for b in blocks]
        return {"text": "\n\n".join(parts) + "\n\n<!-- 由「能力缝演示」插件渲染 -->\n"}

    @api.provide("notes.backlink_rank", "rank")
    @_count("notes.backlink_rank")
    def note_rank(payload):
        """按 doc_title 字母序重排；集合完全不变，宿主会逐项校验后合并。"""
        items = payload.get("items") or []
        if not items:
            return None
        return {"items": sorted(items, key=lambda x: str(x.get("doc_title") or ""))}

    # ---------------------------------------------------------------- AI
    @api.provide("ai.provider", "local")
    @_count("ai.provider")
    def provider(payload):
        """本地回声模型：不联网，返回固定文本。

        真正的插件应该在这里调用自己的模型接口。注意宿主只接受"整段文本"，
        流式下发由宿主切片完成（跨边界传不了生成器）。
        """
        msgs = payload.get("messages") or []
        last = ""
        for m in reversed(msgs):
            if isinstance(m, dict) and m.get("role") == "user":
                content = m.get("content")
                last = content if isinstance(content, str) else ""
                break
        return {
            "text": (f"[演示本地模型] 收到 {len(msgs)} 条消息，最后一条是：{last[:120]}\n"
                     f"这是 capability seam ai.provider 的接管示例，未调用任何云服务。"),
            "model": "demo-local",
            "usage": {"prompt_tokens": 0, "completion_tokens": 0},
        }

    @api.provide("ai.guard", "rules")
    @_count("ai.guard")
    def guard(payload):
        """两条演示规则：请求里带 SECRET 直接拦；回答里把"密钥"打码。"""
        stage = payload.get("stage")
        text = payload.get("text") or ""
        if stage == "request":
            if "SECRET" in text:
                return {"action": "block", "hits": ["SECRET"],
                        "reason": "演示护栏：内容含 SECRET，本次拒绝发往模型"}
            return None
        if stage == "response" and "密钥" in text:
            return {"action": "mask", "text": text.replace("密钥", "***"),
                    "reason": "演示护栏：回答里的敏感词已打码"}
        return None

    # ---------------------------------------------------------------- 运维
    @api.provide("netops.probe", "echo")
    @_count("netops.probe")
    def probe(payload):
        """自定义探测方法：echo（立刻返回存活），演示"新增一种探测方式"。"""
        if payload.get("method") != "echo":
            return None
        target = payload.get("target") or ""
        return {"ok": True, "alive": True, "latency_ms": 1,
                "detail": f"echo {target}：由演示插件应答（未发起真实探测）"}

    # ---------------------------------------------------------------- 应用
    @api.provide("apps.kind", "echo")
    @_count("apps.kind")
    def apps_kind(payload):
        """新增启动类型 echo：不真的启动进程，只回一个成功结果。"""
        if payload.get("kind") != "echo":
            return None
        return {"ok": True, "mode": "plugin", "resolved": payload.get("target") or "",
                "note": "演示插件接管：未真正启动进程"}

    # ---------------------------------------------------------------- 命令接管
    @api.provide("command.provide", "mask")
    @_count("command.provide")
    def provide_command(payload):
        """接管内置命令 netops.mask_prefix：换成插件自己的换算。

        真实场景里这应该实现与原命令**完全一致**的返回契约，否则调用方（界面）
        会拿到它不认识的字段。这里只演示"能接管"。
        """
        if payload.get("command") != "netops.mask_prefix":
            return None
        mask = str((payload.get("args") or {}).get("mask") or "")
        try:
            bits = sum(bin(int(part)).count("1")
                       for part in mask.split(".") if part.isdigit())
        except Exception:
            bits = -1
        return {"result": {"ok": True, "data": {
            "prefix": bits, "by": "demo.mask",
            "note": "这条结果由演示插件提供（原命令被 command.provide 接管）"}}}

    # ---------------------------------------------------------------- 界面
    @api.provide("theme.tokens", "violet")
    @_count("theme.tokens")
    def theme(payload):
        """覆盖主色：浅色/深色各给一套。值必须是不含 ; } 的合法 CSS 值。"""
        accent = api.get_setting("accent") or "#7a5af8"
        return {"vars": {"--accent": accent, "--accent-soft": "#efeaff"},
                "dark_vars": {"--accent": accent, "--accent-soft": "#2a2350"}}

    @api.provide("ui.decorator", "badge")
    @_count("ui.decorator")
    def decorator(payload):
        """给 .demo 文件加一个 DEMO 徽标（只加标记，不改文件名/大小/路径）。"""
        if (payload.get("page") or "") not in ("files", "*"):
            return None
        return {"rules": [{"element": "row", "match": {"ext": [DEMO_SUFFIX]},
                           "badge": "DEMO", "title": "由演示插件标记的自定义格式"}]}

    @api.provide("shell.action", "tray")
    @_count("shell.action")
    def tray(payload):
        """往托盘菜单加一项；点击后执行 demo.tray_hello 命令。

        注意这里只给"标签 + 命令 id"：托盘回调跑在 pystray 自己的线程里，
        宿主不允许插件在托盘线程直接执行函数（那等于把托盘交给插件）。
        """
        if payload.get("hook") != "tray.menu":
            return None
        return {"items": [{"label": "演示：能力缝", "command": "demo.tray_hello"}]}

    @api.on_activate
    def _on():
        api.log(f"能力缝演示已启用：{len(SEAM_IDS)} 个缝全部挂载，软件行为会明显变化")

    @api.on_deactivate
    def _off():
        api.log("能力缝演示已停用：所有接管已摘除")
