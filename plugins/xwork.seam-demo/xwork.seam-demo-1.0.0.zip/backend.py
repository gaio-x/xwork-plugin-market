"""能力缝演示插件。

它把 15 个能力缝各挂了一个实现，用来验证"插件能不能真的接管内置能力"。
**这是一个演示/验收夹具，不是给日常使用的插件**：启用后预览、问答、AI 调用、
主题色都会变。看完请到插件页停用。

写自己的插件时，请照这里的两条规矩来：
1. `@api.provide(缝名)` 之前，manifest.contributes.providers 里必须先声明，
   并且要申请该缝对应的权限——授权页要能提前告诉用户"这个插件要接管什么"。
2. provider 返回 `None` 表示"我不处理这个"，宿主会去找下一个插件或走内置实现。
   返回 dict 才表示"这次由我负责"。**抛异常只会让宿主回退，不会让软件坏掉**。
"""
from __future__ import annotations

# 演示用的自定义格式：纯文本，每行一个块
DEMO_SUFFIX = ".demo"


def register(api):
    # ---------------------------------------------------------------- 命令
    @api.command("demo.info", "能力缝演示：当前接管情况",
                 description="列出本插件挂了哪些能力缝，以及每次调用的次数")
    def info():
        return {"data": {
            "plugin": api.id,
            "seams": ["fs.preview", "fs.extract", "fs.batch", "fs.index",
                      "kb.chunker", "kb.reranker", "kb.answer_post",
                      "ai.provider", "ai.guard", "netops.probe", "apps.kind",
                      "command.provide", "theme.tokens", "ui.decorator",
                      "shell.action"],
            "note": "停用本插件后，以上接管立即消失，宿主恢复内置实现",
        }}

    @api.command("demo.tray_hello", "演示：托盘菜单点了会跑这个命令",
                 description="从托盘菜单触发，验证 shell.action 缝能执行插件命令")
    def tray_hello():
        api.log("托盘菜单触发了 demo.tray_hello")
        return {"data": {"message": "托盘菜单 → 插件命令 已打通"}}

    # ---------------------------------------------------------------- 文件
    @api.provide("fs.preview", "demo")
    def preview(payload):
        """只处理 .demo；其它扩展名返回 None，交给内置预览。"""
        if payload.get("ext") != DEMO_SUFFIX:
            return None
        try:
            got = api.read_text(payload["path"], max_bytes=64 * 1024)
        except Exception:
            return {"ok": False, "error": "演示插件读不到这个文件（检查是否在挂载目录内）"}
        lines = (got.get("content") or "").splitlines()
        blocks = [{"text": ln, "locator": {"line": i + 1},
                   "heading_path": ""} for i, ln in enumerate(lines) if ln.strip()]
        return {"ok": True, "data": {
            "kind": "demo", "fidelity": "plugin", "blocks": blocks[:400],
            "warning": "由「能力缝演示」插件渲染（内置预览不认识 .demo）",
        }}

    @api.provide("fs.extract", "demo")
    def extract(payload):
        """知识库入库时解析 .demo：一行一块，带行号定位。"""
        if payload.get("ext") != DEMO_SUFFIX:
            return None
        try:
            got = api.read_text(payload["path"], max_bytes=2 * 1024 * 1024)
        except Exception:
            return None
        blocks = []
        for i, line in enumerate((got.get("content") or "").splitlines(), 1):
            if line.strip():
                blocks.append({"text": line, "locator": {"line": i},
                               "heading_path": ""})
        if not blocks:
            return None
        return {"kind": "demo", "title": payload.get("name") or "demo",
                "blocks": blocks, "warning": "由演示插件解析"}

    @api.provide("fs.batch", "count")
    def batch_count(payload):
        """演示"插件新增一种批量操作"：统计所选路径的数量与总体积。"""
        if payload.get("action") != "count":
            return None
        paths = payload.get("paths") or []
        total = 0
        dirs = files = 0
        for p in paths:
            try:
                info = api.file_info(p)
            except Exception:
                continue
            if info["is_dir"]:
                dirs += 1
            else:
                files += 1
                total += info["size"]
        return {"ok": True, "data": {"dirs": dirs, "files": files,
                                     "bytes": total, "by": "demo.count"}}

    @api.provide("fs.index", "tag")
    def index_tag(payload):
        """演示"给列表补派生字段"：给每个条目加 demo_tag（前端可用来做筛选）。"""
        entries = payload.get("entries") or []
        if not entries:
            return None
        out = []
        for e in entries:
            item = dict(e)
            item["demo_tag"] = "dir" if e.get("is_dir") else (e.get("ext") or "noext")
            out.append(item)
        return {"entries": out}

    # ---------------------------------------------------------------- 知识库
    @api.provide("kb.chunker", "fixed")
    def chunker(payload):
        """定长分块：每 300 字一块，不做语义切分（只为证明"分块可被接管"）。"""
        blocks = payload.get("blocks") or []
        if not blocks:
            return None
        chunks = []
        for b in blocks:
            text = (b.get("text") or "").strip()
            for i in range(0, len(text), 300):
                piece = text[i:i + 300].strip()
                if len(piece) < 2:
                    continue
                chunks.append({"text": piece,
                               "heading_path": b.get("heading_path") or "",
                               "locator": b.get("locator") or {}})
        return {"chunks": chunks} if chunks else None

    @api.provide("kb.reranker", "reverse")
    def rerank(payload):
        """按路径字母序重排——演示"重排只能改顺序，不能弄丢结果"。"""
        items = payload.get("items") or []
        if not items:
            return None
        order = [i["chunk_id"] for i in sorted(items, key=lambda x: x.get("path") or "")]
        return {"chunk_ids": order, "note": "演示插件按路径重排"}

    @api.provide("kb.answer_post", "notice")
    def answer_post(payload):
        """在答案末尾追加一句附注（设置项可改内容）。"""
        answer = payload.get("answer") or ""
        notice = api.get_setting("notice") or ""
        if not answer or not notice:
            return None
        return {"answer": f"{answer}\n\n{notice}"}

    # ---------------------------------------------------------------- AI
    @api.provide("ai.provider", "local")
    def provider(payload):
        """本地回声模型：不联网，返回固定文本。

        真正的插件应该在这里调用自己的模型接口。注意宿主只接受"整段文本"，
        流式下发由宿主切片完成（跨边界传不了生成器）。
        """
        msgs = payload.get("messages") or []
        last = ""
        for m in reversed(msgs):
            if isinstance(m, dict) and m.get("role") == "user":
                content = m.get("content")
                last = content if isinstance(content, str) else ""
                break
        return {
            "text": (f"[演示本地模型] 收到 {len(msgs)} 条消息，最后一条是：{last[:120]}\n"
                     f"这是 capability seam ai.provider 的接管示例，未调用任何云服务。"),
            "model": "demo-local",
            "usage": {"prompt_tokens": 0, "completion_tokens": 0},
        }

    @api.provide("ai.guard", "rules")
    def guard(payload):
        """两条演示规则：请求里带 SECRET 直接拦；回答里把"密钥"打码。"""
        stage = payload.get("stage")
        text = payload.get("text") or ""
        if stage == "request":
            if "SECRET" in text:
                return {"action": "block", "hits": ["SECRET"],
                        "reason": "演示护栏：内容含 SECRET，本次拒绝发往模型"}
            return None
        if stage == "response" and "密钥" in text:
            return {"action": "mask", "text": text.replace("密钥", "***"),
                    "reason": "演示护栏：回答里的敏感词已打码"}
        return None

    # ---------------------------------------------------------------- 运维
    @api.provide("netops.probe", "echo")
    def probe(payload):
        """自定义探测方法：echo（立刻返回存活），演示"新增一种探测方式"。"""
        if payload.get("method") != "echo":
            return None
        target = payload.get("target") or ""
        return {"ok": True, "alive": True, "latency_ms": 1,
                "detail": f"echo {target}：由演示插件应答（未发起真实探测）"}

    # ---------------------------------------------------------------- 应用
    @api.provide("apps.kind", "echo")
    def apps_kind(payload):
        """新增启动类型 echo：不真的启动进程，只回一个成功结果。"""
        if payload.get("kind") != "echo":
            return None
        return {"ok": True, "mode": "plugin", "resolved": payload.get("target") or "",
                "note": "演示插件接管：未真正启动进程"}

    # ---------------------------------------------------------------- 命令接管
    @api.provide("command.provide", "mask")
    def provide_command(payload):
        """接管内置命令 netops.mask_prefix：换成插件自己的换算。

        真实场景里这应该实现与原命令**完全一致**的返回契约，否则调用方（界面）
        会拿到它不认识的字段。这里只演示"能接管"。
        """
        if payload.get("command") != "netops.mask_prefix":
            return None
        mask = str((payload.get("args") or {}).get("mask") or "")
        try:
            bits = sum(bin(int(part)).count("1")
                       for part in mask.split(".") if part.isdigit())
        except Exception:
            bits = -1
        return {"result": {"ok": True, "data": {
            "prefix": bits, "by": "demo.mask",
            "note": "这条结果由演示插件提供（原命令被 command.provide 接管）"}}}

    # ---------------------------------------------------------------- 界面
    @api.provide("theme.tokens", "violet")
    def theme(payload):
        """覆盖主色：浅色/深色各给一套。值必须是不含 ; } 的合法 CSS 值。"""
        accent = api.get_setting("accent") or "#7a5af8"
        return {"vars": {"--accent": accent, "--accent-soft": "#efeaff"},
                "dark_vars": {"--accent": accent, "--accent-soft": "#2a2350"}}

    @api.provide("ui.decorator", "badge")
    def decorator(payload):
        """给 .demo 文件加一个 DEMO 徽标（只加标记，不改文件名/大小/路径）。"""
        if (payload.get("page") or "") not in ("files", "*"):
            return None
        return {"rules": [{"element": "row", "match": {"ext": [DEMO_SUFFIX]},
                           "badge": "DEMO", "title": "由演示插件标记的自定义格式"}]}

    @api.provide("shell.action", "tray")
    def tray(payload):
        """往托盘菜单加一项；点击后执行 demo.tray_hello 命令。

        注意这里只给"标签 + 命令 id"：托盘回调跑在 pystray 自己的线程里，
        宿主不允许插件在托盘线程直接执行函数（那等于把托盘交给插件）。
        """
        if payload.get("hook") != "tray.menu":
            return None
        return {"items": [{"label": "演示：能力缝", "command": "demo.tray_hello"}]}

    @api.on_activate
    def _on():
        api.log("能力缝演示已启用：15 个缝全部挂载，软件行为会明显变化")

    @api.on_deactivate
    def _off():
        api.log("能力缝演示已停用：所有接管已摘除")
