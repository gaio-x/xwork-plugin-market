# 能力缝演示（xwork.seam-demo）

> 版本 v1.0.0 ｜ 命名空间 `demo` ｜ 权限 `fs.read`、`fs.write`、`network`、`ai.provide`、`ai.guard`、`kb.extend`、`app.launch`、`ui.inject`、`ui.shell`、`command.provide`

## 这个插件做什么

一个验收夹具，不是日常工具。它给 15 个「能力缝」各挂了一个最小实现，用来证明插件确实
能接管内置能力——从 `.demo` 文件的预览与解析、知识库分块与重排，一直到主题变量与托盘菜单。

**默认不启用，启用后行为会明显变化**（预览换实现、回答多一句附注、主色变紫）；停用即全部摘除。

## 怎么用

**命令面板**：`demo.info` 列出本插件挂了哪些缝；`demo.tray_hello` 由托盘菜单触发，
用来验证 `shell.action` 缝能把点击转成插件命令。

**插件页**：插件页底部出现「能力缝演示」面板（`slot: plugins`），面板里可以直接试。

## 提供的能力

| 命令 id | 名称 | 参数 | 说明 |
|---|---|---|---|
| `demo.info` | 能力缝演示：当前接管情况 | 无 | 列出本插件挂了哪些能力缝，以及每次调用的次数 |
| `demo.tray_hello` | 演示：托盘菜单点了会跑这个命令 | 无 | 从托盘菜单触发，验证 shell.action 缝能执行插件命令 |

接管清单（15 条，均在 `contributes.providers` 里预先声明）：`fs.preview` / `fs.extract`（`.demo` 预览与解析）、
`fs.batch` / `fs.index`（批量统计、打标）、`kb.chunker` / `kb.reranker` / `kb.answer_post`（分块、重排、附注）、
`ai.provider` / `ai.guard`（回声模型、SECRET 拦截）、`netops.probe` / `apps.kind`（echo 探测与启动）、
`command.provide`（接管 `netops.mask_prefix`）、`theme.tokens` / `ui.decorator` / `shell.action`（主色、徽标、托盘项）。

## 权限与安全

共 10 项，其中 **3 项高危、默认拒绝、勾选时要单独确认**：`ai.provide`（问答的全部提问与
上下文都会经过插件，可被发往任意地址）、`ui.shell`（往托盘加项、注册全局热键）、
`command.provide`（原地换掉内置命令）。

其余 7 项为中/低危：`fs.read`（读 `.demo` 文本）、`fs.write` / `network` / `app.launch`
（真实实现要写文件、出网、拉进程）、`ai.guard` / `kb.extend`（能看到对话与入库内容）、
`ui.inject`（嵌面板）。**演示代码只读文本，不联网、不写文件、不启动进程**，后三项为真实实现预留；
`provider` 返回 `None` 即不处理，抛异常只让宿主回退——它坏了不会把软件搞挂。

## 文件

- `manifest.json`：清单，声明 15 条缝、2 个命令、1 块面板、2 个设置项与 10 项权限。
- `backend.py` / `panel.html`：逐缝实现（每条一个 `@api.provide` 函数）与插件页面板。
