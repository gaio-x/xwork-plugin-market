# 能力缝演示（xwork.seam-demo）

> 版本 v1.0.0 ｜ 清单 v2 ｜ 命名空间 `demo` ｜ 主程序要求 `>=0.1.0`
> 权限 `fs.read`、`fs.write`、`network`、`ai.provide`、`ai.guard`、`kb.extend`、`app.launch`、`ui.inject`、`ui.shell`、`command.provide`

## 这个插件做什么

一个验收夹具，不是日常工具。它给宿主 `core/plugin/seam.py::SEAMS` 里的 **18 个能力缝全部**
各挂了一个最小实现，用来证明插件确实能接管内置能力——从 `.demo` 文件的预览与解析、
知识库分块与重排、笔记解析/渲染/反链排序，一直到主题变量与托盘菜单。

**默认不启用，启用后行为会明显变化**（预览换实现、回答多一句附注、主色变紫）；停用即全部摘除。
每条缝都有内置回退：provider 返回 `None`、抛异常或超时，宿主都自动走内置实现，软件不会坏。

笔记相关的两条 replace 缝做了克制：`notes.parser` / `notes.renderer` **只在正文带 `XWORK-DEMO`
标记时接管**，普通文档一律走内置解析；`notes.backlink_rank` 只改顺序、绝不增删反链条目。
即使忘了停用，也不会把现有笔记数据写坏。

## 怎么用

**命令面板**：`demo.info` 列出 18 条缝及每条缝的调用次数；`demo.tray_hello` 由托盘菜单触发，
用来验证 `shell.action` 缝能把点击转成插件命令。

**插件页**：插件页底部出现「能力缝演示」面板（`slot: plugins`）。面板逐条列出 18 个缝、
调用次数和「怎么真实触发」，可以点「试一次」用内置样例载荷直接调一次 provider 看返回结构，
也能刷新或清零计数。需要读真实文件的 4 条缝（`fs.preview` / `fs.extract` / `fs.batch`
及依赖宿主资源的场景）按提示到对应页面操作。

## 提供的能力

| 命令 id | 名称 | 参数 | 说明 |
|---|---|---|---|
| `demo.info` | 能力缝演示：当前接管情况 | 无 | 返回 18 条缝的清单、各自调用次数与累计次数 |
| `demo.tray_hello` | 演示：托盘菜单点了会跑这个命令 | 无 | 从托盘菜单触发，验证 shell.action 缝能执行插件命令 |

插件自有接口（面板就是靠它们取数的）：

| 接口 | 方法 | 说明 |
|---|---|---|
| `/api/plugins/xwork.seam-demo/x/seams` | GET | 18 条缝的标签、调用次数、能否试一次、真实触发方式 |
| `/api/plugins/xwork.seam-demo/x/try` | POST | 传 `{"seam":"..."}`，用样例载荷直接调一次 provider，返回结果结构 |
| `/api/plugins/xwork.seam-demo/x/reset` | POST | 清空面板里的调用计数 |

接管清单（18 条，均在 `contributes.providers` 里预先声明，顺序与 `SEAMS` 一致）：

| 分组 | 缝 |
|---|---|
| 文件 | `fs.preview` / `fs.extract`（`.demo` 预览与解析）、`fs.batch` / `fs.index`（批量统计、打标） |
| 知识库 | `kb.chunker` / `kb.reranker` / `kb.answer_post`（分块、重排、附注） |
| 笔记 | `notes.parser` / `notes.renderer` / `notes.backlink_rank`（解析、渲染、反链排序） |
| AI | `ai.provider` / `ai.guard`（回声模型、SECRET 拦截） |
| 运维 / 应用 | `netops.probe` / `apps.kind`（echo 探测与启动） |
| 命令 / 界面 | `command.provide`（接管 `netops.mask_prefix`）、`theme.tokens` / `ui.decorator` / `shell.action`（主色、徽标、托盘项） |

## 权限与安全

共 10 项，其中 **3 项高危、默认拒绝、勾选时要单独确认**：`ai.provide`（问答的全部提问与
上下文都会经过插件，可被发往任意地址）、`ui.shell`（往托盘加项、注册全局热键）、
`command.provide`（原地换掉内置命令）。

其余 7 项为中/低危：`fs.read`（读 `.demo` 文本）、`fs.write` / `network` / `app.launch`
（真实实现要写文件、出网、拉进程）、`ai.guard` / `kb.extend`（能看到对话与入库内容）、
`ui.inject`（嵌面板）。笔记三缝复用 `fs.read` / `fs.write` / `kb.extend`，无需额外授权。

**演示代码只读文本，不联网、不写文件、不启动进程**，后三项为真实实现预留；
调用计数只留在内存里（重启即清空，不落盘）；定时任务与生命周期回调随停用停止。

## 文件

- `manifest.json`：清单，声明 18 条缝、2 个命令、1 块面板、2 个设置项与 10 项权限。
- `backend.py`：逐缝实现（每条一个 `@api.provide` 函数）、`@_count` 计数、3 个自有接口与命令。
- `panel.html`：插件页面板，18 缝表格 + 调用次数 + 试一次 / 刷新 / 清零。
